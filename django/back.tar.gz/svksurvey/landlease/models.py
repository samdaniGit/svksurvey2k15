# -*- coding: utf-8 -*-
from django.db import models
from household.models import * 
from land.models import * 

# Create your models here.
class Registration(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Contracttype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Kind(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Period(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Percent(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Landtanent(models.Model):
	household = models.ForeignKey(Base)
	total = models.FloatField(verbose_name='మొత్తం (య॥ )')
	sharedrent = models.FloatField(verbose_name='పాలుకు ఎంత (య॥ )')
	household_number = models.FloatField()
	fixedrent = models.FloatField(verbose_name='కౌలుకు ఎంత (య॥ )')
	def __str__(self):
                return str(self.total)

class Landleasedin(models.Model):
	tenant_or_not = models.ForeignKey(Yesorno, related_name ="tenant_or_not")
	input_owner_machinary = models.FloatField()
	household = models.ForeignKey(Base)
	input_owner_pumpset = models.FloatField()
	input_owner_seed = models.FloatField()
	annual_fixedrent_cash = models.FloatField()
	landowner_name = models.CharField(max_length=255)
	loan_fromowner_interestfree = models.FloatField()
	household_number = models.FloatField()
	landowner_caste = models.ForeignKey(Caste)
	input_owner_pesticide = models.FloatField()
	loan_fromowner_withinterest = models.FloatField()
	tenurial_registration = models.ForeignKey(Registration)
	input_owner_fertiliser = models.FloatField()
	tenurial_contracttype = models.ForeignKey(Contracttype)
	extent = models.FloatField()
	qty_hay_byowner = models.FloatField()
	input_owner_electricity = models.FloatField()
	annual_fixedrent_kind = models.ForeignKey(Kind)
	input_owner_manure = models.FloatField()
	landowner_extent_landholding = models.FloatField()
	landtype = models.ForeignKey(Landtype)
	tenurial_sincewhen = models.CharField(max_length=255)
	landowner_occupation = models.ForeignKey(Occupation)
	def __str__(self):
                return self.landowner_name

class Landleaser(models.Model):
	household = models.ForeignKey(Base)
	total = models.FloatField(verbose_name='మొత్తం (య॥ )')
	sharedrent = models.FloatField(verbose_name='పాలుకు ఎంత (య॥ )')
	household_number = models.FloatField()
	fixedrent = models.FloatField(verbose_name='కౌలుకు ఎంత (య॥ )')
	def __str__(self):
                return str(self.household_number)

class Landleasedout(models.Model):
	leaseout_or_not = models.ForeignKey(Yesorno, related_name ="leaseout_or_not")
	household = models.ForeignKey(Base)
	input_you_pesticide = models.FloatField()
	input_you_pumpset = models.FloatField()
	annual_fixedrent_cash = models.FloatField()
	landtype = models.ForeignKey(Landtype)
	household_number = models.FloatField()
	landtenant_name = models.CharField(max_length=255)
	input_you_seed = models.FloatField()
	input_you_machinary = models.FloatField()
	input_you_fertiliser = models.FloatField()
	input_you_manure = models.FloatField()
	tenurial_registration = models.ForeignKey(Registration)
	tenurial_contracttype = models.ForeignKey(Contracttype)
	extent = models.FloatField()
	landtenant_extent_landholding = models.FloatField()
	annual_fixedrent_kind = models.ForeignKey(Kind)
	landtenant_caste = models.ForeignKey(Caste)
	loan_fromyou_withinterest = models.FloatField()
	loan_fromyou_interestfree = models.FloatField()
	qty_hay_bytenant = models.FloatField()
	landtenant_occupation = models.ForeignKey(Occupation)
	input_you_electricity = models.FloatField()
	tenurial_sincewhen = models.CharField(max_length=255)
	def __str__(self):
                return self.landtenant_name

class Mortgagedin(models.Model):
	businessman_caste = models.ForeignKey(Caste)
	interest = models.FloatField()
	household_number = models.FloatField()
	year_mortgage = models.CharField(max_length=255)
	household = models.ForeignKey(Base)
	businessman_name = models.CharField(max_length=255)
	businessman_occupation = models.ForeignKey(Occupation)
	mortgage_period = models.ForeignKey(Period)
	extent = models.FloatField()
	landtype = models.ForeignKey(Landtype)
	mortgage_amount = models.FloatField()
	def __str__(self):
                return self.businessman_name
class Mortgagedout(models.Model):
	year_mortgage = models.CharField(max_length=255)
	interest = models.FloatField()
	household_number = models.FloatField()
	mortgagee_caste = models.ForeignKey(Caste)
	mortgagee_name = models.CharField(max_length=255)
	household = models.ForeignKey(Base)
	mortgage_period = models.ForeignKey(Period)
	extent = models.FloatField()
	landtype = models.ForeignKey(Landtype)
	mortgagee_occupation = models.ForeignKey(Occupation)
	mortgage_amount = models.FloatField()
	def __str__(self):
                return self.mortgagee_name

class Sharerentin(models.Model):
	sharedin_or_not = models.ForeignKey(Yesorno, related_name ="sharedin_or_not")
	input_owner_machinary_percent = models.ForeignKey(Percent, related_name = 'input_owner_machinary_percent')
	input_owner_machinary_rs = models.FloatField()
	household = models.ForeignKey(Base)
	period = models.ForeignKey(Period)
	since_when_leased = models.CharField(max_length=255)
	landowner_name = models.CharField(max_length=255)
	input_owner_manure_rs = models.FloatField()
	household_number = models.FloatField()
	input_owner_labor_rs = models.FloatField()
	landowner_caste = models.ForeignKey(Caste)
	input_owner_elec_rs = models.FloatField()
	input_owner_pump_percent = models.ForeignKey(Percent, related_name = 'input_owner_pump_percent')
	input_owner_pest_rs = models.FloatField()
	input_owner_seed_rs = models.FloatField()
	owner_share_hay_percent = models.ForeignKey(Percent, related_name = 'owner_share_percent')
	input_owner_fert_percent = models.ForeignKey(Percent, related_name = 'input_owner_fert_percent')
	input_owner_elec_percent = models.ForeignKey(Percent, related_name = 'input_owner_elec_percent')
	loan_by_owner_amt = models.FloatField()
	owner_share_crop_qty = models.FloatField()
	input_owner_labor_percent = models.ForeignKey(Percent, related_name = 'input_owner_labor_percent')
	input_owner_seed_percent = models.ForeignKey(Percent, related_name = 'input_owner_seed_percent')
	input_owner_fert_rs = models.FloatField()
	owner_share_crop_percent = models.ForeignKey(Percent, related_name = 'owner_share_crop_percent')
	extent = models.FloatField()
	input_owner_pest_percent = models.ForeignKey(Percent, related_name = 'input_owner_pest_percent')
	loan_by_owner_interestfree = models.FloatField()
	loan_by_owner_interest = models.FloatField()
	loan_by_owner_rateofinterest = models.FloatField()
	input_owner_manure_percent = models.ForeignKey(Percent, related_name = 'input_owner_manure_percent')
	landowner_extent_hold = models.FloatField()
	landtype = models.ForeignKey(Landtype)
	owner_share_hay_qty = models.FloatField()
	input_owner_pump_rs = models.FloatField()
	registered_or_not = models.ForeignKey(Registration)
	landowner_occupation = models.ForeignKey(Occupation)
	def __str__(self):
                return self.landowner_name

class Sharerentout(models.Model):
	sharednot_or_not = models.ForeignKey(Yesorno, related_name ="sharednot_or_not")
	input_you_elec_percent = models.ForeignKey(Percent, related_name = "input_you_elec_percent")
	cropper_occupation = models.ForeignKey(Occupation, related_name = "cropper_occupation")
	household = models.ForeignKey(Base)
	input_you_seed_percent = models.ForeignKey(Percent, related_name = "input_you_seed_percent")
	period = models.ForeignKey(Period, related_name = "period")
	loan_by_you_interestfree = models.FloatField()
	loan_by_you_interest = models.FloatField()
	loan_by_owner_rateofinterest = models.FloatField()
	since_when_leased = models.CharField(max_length=255)
	input_you_pest_rs = models.FloatField()
	input_you_pump_rs = models.FloatField()
	tenant_share_hay_qty = models.FloatField()
	household_number = models.FloatField()
	input_you_elec_rs = models.FloatField()
	input_you_fert_rs = models.FloatField()
	input_you_labor_rs = models.FloatField()
	input_you_fert_percent = models.ForeignKey(Percent, related_name = "input_you_fert_percent")
	cropper_name = models.CharField(max_length=255)
	input_you_machinary_percent = models.ForeignKey(Percent, related_name = "input_you_machinary_percent")
	input_you_manure_rs = models.FloatField()
	cropper_caste = models.ForeignKey(Caste, related_name = "cropper_caste")
	cropper_extent_hold = models.FloatField()
	loan_by_you_amt = models.FloatField()
	input_you_machinary_rs = models.FloatField()
	extent = models.FloatField()
	tenant_share_crop_percent = models.ForeignKey(Percent, related_name = "tenant_share_crop_percent")
	input_you_labor_percent = models.ForeignKey(Percent, related_name = "input_you_labor_percent")
	tenant_share_hay_percent = models.ForeignKey(Percent, related_name = "tenant_share_hay_percent")
	input_you_seed_rs = models.FloatField()
	input_you_manure_percent = models.ForeignKey(Percent, related_name = "input_you_manure_percent")
	tenant_share_crop_qty = models.FloatField()
	landtype = models.ForeignKey(Landtype, related_name = "landtype")
	input_you_pump_percent = models.ForeignKey(Percent, related_name = "input_you_pump_percent")
	registered_or_not = models.ForeignKey(Registration, related_name = "registered_or_not")
	input_you_pest_percent = models.ForeignKey(Percent, related_name = "input_you_pest_percent")
	def __str__(self):
                return self.household_number

class Tenantproblems(models.Model):
	reason_compelled_one = models.CharField(max_length=255)
	inherited_problems = models.ForeignKey(Yesorno, related_name = "inherited_problems")
	reason_compelled = models.ForeignKey(Yesorno, related_name = "reason_compelled")
	household = models.ForeignKey(Base)
	why_wageslow_manage = models.ForeignKey(Yesorno, related_name = "why_wageslow_manage")
	why_lowrent_profitable = models.ForeignKey(Yesorno, related_name = "why_lowrent_profitable")
	nonereason_tenant = models.ForeignKey(Yesorno, related_name = "nonereason_tenant")
	why_noskill_urban = models.ForeignKey(Yesorno, related_name = "why_noskill_urban")
	household_number = models.FloatField()
	why_tenancy_respectable = models.ForeignKey(Yesorno, related_name = "why_tenancy_respectable")
	comments = models.CharField(max_length=255)
	because_debt_to_leaser = models.ForeignKey(Yesorno, related_name = "because_debt_to_leaser")
	loan_landowner_prior_tenancy = models.ForeignKey(Yesorno, related_name = "loan_landowner_prior_tenancy")
	reason_compelled_three = models.CharField(max_length=255)
	lack_anyother_option = models.ForeignKey(Yesorno, related_name = "lack_anyother_option")
	provide_freeservice_owner = models.ForeignKey(Yesorno, related_name = "provide_freeservice_owner")
	other_reasons = models.CharField(max_length=255)
	why_for_foodgrains = models.ForeignKey(Yesorno, related_name = "why_for_foodgrains")
	nature_contract_written = models.ForeignKey(Yesorno, related_name = "nature_contract_written")
	dueto_lack_opportunites = models.ForeignKey(Yesorno, related_name = "dueto_lack_opportunites")
	nota_comeout_otherreasons = models.ForeignKey(Yesorno, related_name = "nota_comeout_otherreasons")
	why_inability_wagework = models.ForeignKey(Yesorno, related_name = "why_inability_wagework")
	reason_compelled_two = models.CharField(max_length=255)
	why_ownland_notsufficient = models.ForeignKey(Yesorno, related_name = "why_ownland_notsufficient")
	why_opportunity_cattle = models.ForeignKey(Yesorno, related_name = "why_opportunity_cattle")
	debt_inherited = models.ForeignKey(Yesorno, related_name = "debt_inherited")
	nature_contract_verbal = models.ForeignKey(Yesorno, related_name = "nature_contract_verbal")
	because_debt_to_leaser_amt = models.FloatField()
	def __str__(self):
                return str(self.household_number)

class Interlinks(models.Model):
	comodity_labour = models.ForeignKey(Yesorno, related_name = "comodity_labour")
	household_number = models.FloatField()
	land_labour = models.ForeignKey(Yesorno, related_name = "land_labour")
	household = models.ForeignKey(Base, related_name = "f_household")
	inputs_land = models.ForeignKey(Yesorno, related_name = "inputs_land")
	inputs_loans = models.ForeignKey(Yesorno, related_name = "inputs_loans")
	inputs_commodity = models.ForeignKey(Yesorno, related_name = "inputs_commodity")
	loans_commodity = models.ForeignKey(Yesorno, related_name = "loans_commodity")
	inputs_labour = models.ForeignKey(Yesorno, related_name = "inputs_labour")
	loans_land = models.ForeignKey(Yesorno, related_name = "loans_land")
	land_commodity = models.ForeignKey(Yesorno, related_name = "land_commodity")
	loans_labour = models.ForeignKey(Yesorno, related_name = "loans_labour")
	def __str__(self):
                return self.comodity_labour
