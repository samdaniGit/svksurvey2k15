# -*- coding: utf-8 -*-
from django.db import models
from household.models import * 
 
# Create your models here.
class Landtype(models.Model):
	name = models.CharField(verbose_name= 'భూమి రకము', max_length=255)
	def __str__(self):
                return self.name

class Irrigationsource(models.Model):
	name = models.CharField(verbose_name= 'సాగు నీటి వసతి_నీటి వనరు', max_length=255)
	def __str__(self):
                return self.name

class Irrigationflow(models.Model):
	name = models.CharField(verbose_name='సాగు నీటి వసతి_పారుదల', max_length=255)
	def __str__(self):
                return self.name

class Irrigationownship(models.Model):
	name = models.CharField(verbose_name='సాగు నీటి వసతి_యజమాన్యం', max_length=255)
	def __str__(self):
                return self.name

class Aquireland(models.Model):
	name = models.CharField(verbose_name='భూమి విలువ', max_length=255)
	def __str__(self):
                return self.name

class Reasonforsale(models.Model):
	name = models.CharField(verbose_name='అమ్మకానికి కారణం', max_length=255)
	def __str__(self):
                return self.name

class Currentownership(models.Model):
	landowned_or_not = models.ForeignKey(Yesorno, related_name = 'landowned_or_not')
	household_number = models.FloatField(verbose_name= u'కుటుం బ సం ఖ్య ')
	irrigationownship = models.ForeignKey(Irrigationownship, verbose_name= u'సాగు నీటి వసతి_యజమాన్యం ')
	household = models.ForeignKey(Base, verbose_name = u'కుటుంబ యజామాని పేరు ')
	how_aquireland = models.ForeignKey(Aquireland, verbose_name= u'భూమి ఎలా వచ్హింది')
	extent_of_owned = models.FloatField( verbose_name= u'స్వంత భుమి(ఎకరాలు)')
	value = models.FloatField( verbose_name= u'భూమి విలువ')
	patta_for_land = models.ForeignKey(Yesorno,related_name = 'patta_for_land', verbose_name= u'పట్టా ఉందా లేదా?')
	landtype = models.ForeignKey(Landtype, verbose_name= u'భూమి రకము')
	irrigationflow = models.ForeignKey(Irrigationflow, verbose_name= u'సాగు నీటి వసతి_పారుదల')
	irrigationsource = models.ForeignKey(Irrigationsource, verbose_name= u'సాగు నీటి వసతి_నీటి వనరు')
	def __str__(self):
                return self.irrigationownship

class Landsold(models.Model):
 	land_sold_or_not = models.ForeignKey(Yesorno, related_name = 'land_sold_or_not')
	buyer_name = models.CharField(max_length=255, verbose_name= u'కొన్నవారు పేరు')
	household_number = models.FloatField(verbose_name= u'కుటుంబ సంఖ్య')
	price_land = models.FloatField(verbose_name= u'యాకరం ధర')
	type_of_land = models.ForeignKey(Landtype, verbose_name= u'భూమి రకము')
	year_of_sale = models.ForeignKey(Year, verbose_name= u'అమ్మిన సంవత్సరం ')
	household = models.ForeignKey(Base, verbose_name = u'కుటుంబ యజామాని పేరు ')
	buyer_occupation = models.ForeignKey(Occupation, verbose_name= u'కొన్నవారు_వౄతి')
	buyer_place_residence = models.CharField(max_length=255, verbose_name= u'కొన్నవారు_ఊరు')
	buyer_catse = models.ForeignKey(Caste, verbose_name= u'కొన్నవారు_కులం ')
	extent = models.FloatField(verbose_name= u'విస్తీర్ణము')
	reason_for_sale = models.ForeignKey(Reasonforsale, verbose_name= u'అమ్మాటానికి కారణాలు')
	def __str__(self):
                return self.buyer_name

class Landbought(models.Model):
	land_bought_or_not = models.ForeignKey(Yesorno, related_name = 'land_bought_or_not')
	seller_catse = models.ForeignKey(Caste, verbose_name= u'అమ్మిననారు_కులం ')
	seller_occupation = models.ForeignKey(Occupation, verbose_name= u'అమ్మిననారు_వౄతి')
	household_number = models.FloatField(verbose_name= u'కుటుంబ సంఖ్య')
	seller_name = models.CharField(max_length=255, verbose_name= u'అమ్మిననారు_పేరు')
	price_land = models.FloatField(verbose_name= u'యాకరం ధర')
	type_of_land = models.ForeignKey(Landtype, verbose_name= u'భూమి రకం ')
	household = models.ForeignKey(Base, verbose_name = u'కుటుంబ యజామాని పేరు ')
	comments = models.CharField(max_length=255, verbose_name= u'కామెంట్స్')
	extent = models.FloatField(verbose_name= u'విస్తీర్ణము ')
	seller_place_residence = models.CharField(max_length=255, verbose_name= u'అమ్మినవారు_ఊరు')
	year_of_purchase = models.ForeignKey(Year, verbose_name= u'కొన్న  సంవత్సరం')
	income_source = models.CharField(max_length=255, verbose_name = u'ఆదాయ వనరు ')
	def __str__(self):
                return self.seller_name
