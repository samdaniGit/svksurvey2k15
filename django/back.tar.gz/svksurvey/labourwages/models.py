# -*- coding: utf-8 -*-
from django.db import models
from household.models import *
from land.models import *
from landlease.models import *
from cropping.models import *

# Create your models here.
class Agoperation(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Wagetype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Workprogramme(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Obligationtype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Taskdescription(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Collecteditems(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Magency(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Cheatingfaced(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Workdescription(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Animaltype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Animalproduction(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Labourdays(models.Model):
	labour_deployed = models.ForeignKey(Yesorno, related_name ="labour_deployed")
	daily_labour_days_m = models.FloatField(verbose_name='దినకూలిలు పని దినాలు పురుషులు')
	exchange_labour_hours_m = models.FloatField(verbose_name='బదుళ్లు  పని గంటలు పురుషులు ')
	daily_labour_wages_c = models.FloatField(verbose_name='దినకూలిలు కూలిరేట్లు  పిల్లలు')
	family_labour_days_m = models.FloatField(verbose_name='కుటుంబశ్రమ పని దినాలు పురుషులు ')
	exchange_labour_hours_c = models.FloatField(verbose_name='బదుళ్లు  పని గంటలు  పిల్లలు ')
	family_labour_hours_w = models.FloatField(verbose_name='కుటుంబశ్రమ పని దినాలు స్త్రీ లు ')
	household = models.ForeignKey(Base)
	daily_labour_hours_m = models.FloatField(verbose_name='దినకూలిలు పని గంటలు పురుషులు')
	daily_labour_wages_m = models.FloatField(verbose_name='దినకూలిలు కూలిరేట్లు  పురుషులు')
	crop = models.ForeignKey(Crop, verbose_name='పంట ')
	family_labour_hours_m = models.FloatField(verbose_name='కుటుంబశ్రమ పని గంటలు పురుషులు')
	daily_labour_wages_w = models.FloatField(verbose_name='దినకూలిలు కూలిరేట్లు  స్త్రీ లు ')
	daily_labour_hours_c = models.FloatField(verbose_name='దినకూలిలు పని గంటలు పిల్లలు ')
	daily_labour_days_w = models.FloatField(verbose_name='దినకూలిలు పని దినాలు స్త్రీలు ')
	family_labour_hours_c = models.FloatField(verbose_name='కుటుంబశ్రమ పని గంటలు పిల్లలు')
	family_labour_days_w = models.FloatField(verbose_name='కుటుంబశ్రమ పని దినాలు స్త్రీ లు ')
	longterm_labour_hours_c = models.FloatField()
	household_number = models.FloatField()
	longterm_labour_days_w = models.FloatField()
	longterm_labour_hours_m = models.FloatField()
	comments = models.CharField(max_length=255, verbose_name='కామెంట్స్  ')
	longterm_labour_days_m = models.FloatField()
	longterm_labour_hours_w = models.FloatField()
	longterm_labour_days_c = models.FloatField()
	family_labour_days_c = models.FloatField(verbose_name='కుటుంబశ్రమ పని దినాలు పిల్లలు ')
	exchange_labour_days_m = models.FloatField(verbose_name='బదుళ్లు  పని దినాలు ')
	machine_labourpayment = models.FloatField(verbose_name='యంత్రాలతో పని అయిన ఖర్చు ')
	daily_labour_hours_w = models.FloatField(verbose_name='దినకూలిలు పని గంటలు స్త్రీ లు')
	daily_labour_days_c = models.FloatField(verbose_name='దినకూలిలు పని దినాలు  పిల్లలు')
	extent = models.FloatField(verbose_name='విస్తీర్ణ ')
	machine_labour_workhours = models.FloatField(verbose_name='యంత్రాలతో పని గంటలు ')
	exchange_labour_days_w = models.FloatField(verbose_name='బదుళ్లు  పని దినాలు స్త్రీ లు ')
	agricultural_operation = models.ForeignKey(Agoperation, related_name = "agricultural_operation",verbose_name='పని వివరము ')
	exchange_labour_hours_w = models.FloatField(verbose_name='బదుళ్లు  పని గంటలు స్త్రీ లు')
	piece_rated_kind = models.FloatField()
	exchange_labour_days_c = models.FloatField(verbose_name='బదుళ్లు  పని దినాలు  పిల్లలు')
	piece_rated_cash = models.FloatField()
	def __str__(self):
                return str(self.daily_labour_days_m)

class Wages(models.Model):
	is_agricultural_labour = models.ForeignKey(Yesorno, related_name ="is_agricultural_labour")
	labour_days = models.FloatField(verbose_name=u'పని దినాలు ')
	contract_howmany_workers = models.FloatField(verbose_name=u'కాంట్రాక్టు పని అయితే ఎంత మందికి ఇచ్చారు')
	contract_remuniration = models.FloatField(verbose_name='పని పూర్తి చేయడానికి ఇచ్చిన డబ్బు ')
	household_number = models.FloatField()
	contract_total_wage = models.FloatField(verbose_name='పని వివరము ')
	contract_number_acres = models.FloatField(verbose_name=u'కాంట్రాక్టు పని అయితే ఎన్ని ఎకరాలు ')
	type_wage = models.ForeignKey(Wagetype, related_name = "type_wage",verbose_name=u'దిన కూలి /పిన్ రేట్ ')
	wagerates_increased = models.ForeignKey(Yesorno, related_name = "wagerates_increased",verbose_name=u'కూలి రేట్లు పెరిగాయ ?')
	earnings_cash = models.FloatField()
	contract_wage_rate = models.FloatField(verbose_name=u'కాంట్రాక్టు పని అయితే కూలి రేటు ')
	crop = models.ForeignKey(Crop,verbose_name=u'పంట ')
	work_hours = models.FloatField(verbose_name=u'పని గంటలు ')
	place_work = models.CharField(max_length=255,verbose_name=u'పని స్థలం ')
	migrations_declined = models.ForeignKey(Yesorno, related_name = "migrations_declined",verbose_name=u'వలసలు తగ్గాయా ?')
	worker_name = models.CharField(max_length=255,verbose_name=u'వ్యవసాయ కూలి పేరు ')
	isthere_change_peasants = models.ForeignKey(Yesorno, related_name = "isthere_change_peasants",verbose_name='మీ యెడల భూమి గల రైతు వైఖరి లో ఏమైన మార్పు కనిపించిందా ?')
	income = models.FloatField(verbose_name=u'పీన్  రేటు /కాంట్రాక్టు అయితే మొత్తం సంపాదన') 
	has_baragaining_power_increased = models.ForeignKey(Yesorno, related_name = "has_baragaining_power_increased",verbose_name=u'రైతులతో వ్యవహరించటం లో మీకు వెసులబతు పెరిగిందా ?')
	operation = models.ForeignKey(Agoperation, related_name = "operation", verbose_name='పని వివరము ')
	earnings_kind = models.ForeignKey(Kind, related_name = "earnings_kind")
	household = models.ForeignKey(Base)
	def __str__(self):
                return self.worker_name

class Nonaglabour(models.Model):
 	workedin_nonag_operation = models.ForeignKey(Yesorno, related_name ="workedin_nonag_operation")
	number_days = models.FloatField(verbose_name=u'పనిదినాలు ')
	type_wage_contract = models.ForeignKey(Wagetype, related_name = "type_wage_contract", verbose_name= u'దినకూలి ')
	description_specify_programme = models.ForeignKey(Workprogramme, related_name = "description_specify_programme",verbose_name=u'పని వివరము ')
	household_number = models.FloatField()
	household = models.ForeignKey(Base)
	totalearnings_kind = models.ForeignKey(Kind, related_name = "totalearnings_kind")
	place_work = models.CharField(max_length=255,verbose_name=u'పని స్థలము')
	worker_name = models.CharField(max_length=255,verbose_name=u'వ్యవసాయేతర కార్మికుడి పేరు ')
	totalearnings_cash = models.FloatField()
	work_hours = models.FloatField(verbose_name=u'పని గంటలు ')
	income_total = models.FloatField(verbose_name=u'పీన్  రేటు /కాంట్రాక్టు అయితే మొత్తం సంపాదన')
	def __str__(self):
                return self.worker_name

class Empfreedom(models.Model):
	does_unpaidlabour_service_text = models.CharField(max_length=255, verbose_name= u'మీ కుటుంబంలో ఎవరైనా ఏ యజమనికైన ఉచితంగా కాని తకువ ప్రతిఫలానికి గాని పని చేస్తారా? వివరము')
	household_obligated_castduties_two = models.CharField(max_length=255, verbose_name= u'')
	household_number = models.FloatField()
	are_familyfree_towork = models.ForeignKey(Yesorno, related_name = "are_familyfree_towork", verbose_name= u'మీకు ఇష్టం వచ్చిన యజమానికి కూలికి పోవటానికి  మీకు  స్వేచ్ఛ  ')
	member_family_harassment = models.ForeignKey(Yesorno, related_name = "member_family_harassment")
	household = models.ForeignKey(Base)
	household_obligated_castduties_one = models.CharField(max_length=255, verbose_name= u'')
	does_unpaidlabour_service = models.ForeignKey(Yesorno, related_name = "does_unpaidlabour_service", verbose_name= u'మీ కుటుంబంలో ఎవరైనా ఏ యజమనికైన ఉచితంగా కాని తకువ ప్రతిఫలానికి గాని పని చేస్తారా?')
	are_familyfree_towork_text = models.CharField(max_length=255, verbose_name= u'మీకు ఇష్టం వచ్చిన యజమానికి కూలికి పోవటానికి  మీకు  స్వేచ్ఛ  వివరము')
	member_family_forced_particularemployer = models.ForeignKey(Yesorno, related_name = "member_family_forced_particularemployer", verbose_name= u'మీ కుటుంబంలో ఏ ఒక్కరైన ఒక ప్రత్యేక యజమానికి పని  చేసేలా నిర్భందించబడ్డార ?')
	household_obligated_castduties_three = models.CharField(max_length=255)
	any_murders_longtermlabours = models.ForeignKey(Yesorno, related_name = "any_murders_longtermlabours")
	member_family_forced_indebted = models.ForeignKey(Yesorno, related_name = "member_family_forced_indebted", verbose_name='అప్పు ఎచినవారు ఇచిన వారు నిర్భందించారా ?')
	member_family_harassment =  models.ForeignKey(Yesorno, related_name = " member_family_harassment", verbose_name= u' మీరు లేదా  మీ కుటుంబంలో ఎవరైనా ఎప్పుడైనా యజమాని నుండి వేదింపులకు గురైయ్యార ?')
	any_murders_longtermlabours =  models.ForeignKey(Yesorno, related_name = "any_murders_longtermlabours", verbose_name= u' పాలేరు హత్యలు ఏమైనా జరిగాయా ?')
	household_obligated_castduties_one = models.CharField(max_length=255, verbose_name= u'మీ కుటుంబం , కులవృత్తి పరమైన పనులు ఏమైన నిర్భంధంగా చేయవలసి వచ్చిందా ? 1')
	household_obligated_castduties_two = models.CharField(max_length=255, verbose_name= u'మీ కుటుంబం , కులవృత్తి పరమైన పనులు ఏమైన నిర్భంధంగా చేయవలసి వచ్చిందా ? 2')	
	household_obligated_castduties_three = models.CharField(max_length=255, verbose_name= u'మీ కుటుంబం , కులవృత్తి పరమైన పనులు ఏమైన నిర్భంధంగా చేయవలసి వచ్చిందా ? 3')
	worker_name = models.CharField(max_length=255, verbose_name= u'కార్మికుడి పేరు ')
	employer_name = models.CharField(max_length=255, verbose_name= u'యాజమాని పేరు ')
	employer_caste =  models.ForeignKey(Caste, related_name = "employer_caste", verbose_name= u'కులం ' )
	employer_landowned = models.FloatField(verbose_name= u'భూమి ')
	type_obligation = models.ForeignKey(Obligationtype, related_name = "type_obligation", verbose_name= u'ఎలాంటి వత్తిడికి గురయ్యారు')
	description_task = models.ForeignKey(Taskdescription, related_name= "description_task", verbose_name= u'పని వివరము ')
	labourdays_worked =  models.FloatField(verbose_name= u'సంవత్సరానికి పనిచేసే రోజులు ')
	hours_work =  models.FloatField(verbose_name= u'ఎన్ని గంటలు ')
	work_payment =  models.FloatField(verbose_name= u'ఇచ్చిన ప్రతిఫలం ')
	comments =  models.CharField(max_length=255, verbose_name= u'కామెంట్స్ ') 
	def __str__(self):
                return str(self.household_number)

class Income(models.Model):
	where_sold = models.CharField(max_length=255,verbose_name=u'ఎక్కడ అమ్మారు ')
	quantity_sold = models.FloatField(verbose_name=u'అమ్మినది ')
	household = models.ForeignKey(Base,verbose_name=u'ఇంట్లో వాడుకున్నది ఎంత ?')
	marketing_agency = models.ForeignKey(Magency, related_name = "marketing_agency",verbose_name=u'మార్కెట్టింగ్ ఏజెన్సీ ')
	price = models.FloatField(verbose_name=u'ధర ')
	cheating_youface = models.ForeignKey(Cheatingfaced, related_name = "cheating_youface",verbose_name=u'జరిగే మోసాలు')
	total_earnings = models.FloatField(verbose_name=u'మొత్తం ఆదాయం ')
	item_collected = models.ForeignKey(Collecteditems, related_name = "item_collected",verbose_name=u'సేకరించిన అడవి ఉత్త్పతి ఎంత   ?')
	quantity_consumed = models.FloatField()
	household_number = models.FloatField()
	def __str__(self):
                return str(self.quantity_sold)

class Incomeother(models.Model):
	household_number = models.FloatField(verbose_name=u'వ నెం ')
	work_description = models.ForeignKey(Workdescription, related_name = "work_description",verbose_name=u'పని వివరము')
	household = models.ForeignKey(Base)
	comments = models.CharField(max_length=255,verbose_name=u'కామెంట్స్ ')
	worker_name = models.CharField(max_length=255,verbose_name=u'పని చేసేవారి పేరు ')
	work_place = models.CharField(max_length=255,verbose_name=u'పని స్థలము ')
	totalnet_earnings = models.FloatField(verbose_name=u'గత సంవత్సరం ఒక నెల సంపాదన ')
	s_no = models.ForeignKey(Numbers)
	def __str__(self):
                return self.worker_name

class Animalsource(models.Model):
	animal_owned = models.ForeignKey(Yesorno, related_name ="animal_owned")
	insurance = models.FloatField(verbose_name=u' ఇన్సురన్సు ')
	labour_charges = models.FloatField(verbose_name=u'కూల్లి ఖర్చు ')
	household_number = models.FloatField(verbose_name=u'సంఖ్య ')
	feed_purchased = models.FloatField(verbose_name=u'మేత ఖర్చులు కొన్నది ')
	age = models.ForeignKey(Numbers, related_name = "age",verbose_name=u'వయసు ')
	veternary_charges = models.FloatField(verbose_name=u'పశు వైద్య ఖర్చులు ')
	income_price = models.FloatField(verbose_name= u'ధర / బాడుగ రూ ॥ ')
	rent_for_land = models.FloatField()
	nu = models.ForeignKey(Numbers, related_name = "nu", verbose_name= u'ఒక దాని విలువ ')
	total_income = models.FloatField(verbose_name=u'మొత్తం ఆదాయం')
	income_production = models.ForeignKey(Animalproduction, related_name = "income_production", verbose_name= u'ఉత్పత్తి / పని రూ  ॥')
	maintanence_buildings = models.FloatField(verbose_name=u'నిర్వహణ ఖర్చులు రూ ')
	others = models.FloatField(verbose_name=u'ఇతరములు ')
	interest_loans_livestock = models.FloatField(verbose_name=u'అప్పుల మీద వడ్డీ ')
	feed_home_grown = models.FloatField(verbose_name=u'మేత ఖర్చులు ఇంటి తయారి ')
	total_present_value = models.FloatField(verbose_name= u'మేత ఖర్చులు మొత్తం విలువ రూ ')
	type = models.ForeignKey(Animaltype, related_name = "type",verbose_name=u' రకము ')
	household = models.ForeignKey(Base)
	earnings = models.FloatField(verbose_name= u'నికర ఆదాయం రూ ')
	def __str__(self):
                return str(self.insurance)

