from django.contrib import admin
from labourwages.models import *

# Register your models here.
class AgoperationAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Agoperation,AgoperationAdmin)

class WagetypeAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Wagetype,WagetypeAdmin)

class WorkprogrammeAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Workprogramme,WorkprogrammeAdmin)

class ObligationtypeAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Obligationtype,ObligationtypeAdmin)

class TaskdescriptionAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Taskdescription,TaskdescriptionAdmin)

class CollecteditemsAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Collecteditems,CollecteditemsAdmin)

class MagencyAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Magency,MagencyAdmin)

class CheatingfacedAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Cheatingfaced,CheatingfacedAdmin)

class WorkdescriptionAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Workdescription,WorkdescriptionAdmin)

class AnimaltypeAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Animaltype,AnimaltypeAdmin)

class AnimalproductionAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Animalproduction,AnimalproductionAdmin)

class LabourdaysAdmin(admin.ModelAdmin):
	fields=('household','household_number','labour_deployed','crop','extent','agricultural_operation','family_labour_days_m','family_labour_days_w','family_labour_days_c','family_labour_hours_m','family_labour_hours_w','family_labour_hours_c','daily_labour_days_m','daily_labour_days_w','daily_labour_days_c','daily_labour_hours_m','daily_labour_hours_w','daily_labour_hours_c','daily_labour_wages_m','daily_labour_wages_w','daily_labour_wages_c','exchange_labour_days_m','exchange_labour_days_w','exchange_labour_days_c','exchange_labour_hours_m','exchange_labour_hours_w','exchange_labour_hours_c','piece_rated_cash','piece_rated_kind','machine_labour_workhours','machine_labourpayment','comments',)
admin.site.register(Labourdays,LabourdaysAdmin)

class WagesAdmin(admin.ModelAdmin):
	fields=('household','household_number','is_agricultural_labour','worker_name','crop','operation','type_wage','place_work','labour_days','work_hours','earnings_cash','earnings_kind','income','contract_number_acres','contract_remuniration','contract_howmany_workers','contract_wage_rate','contract_total_wage','wagerates_increased','migrations_declined','isthere_change_peasants','has_baragaining_power_increased',)
admin.site.register(Wages,WagesAdmin)

class NonaglabourAdmin(admin.ModelAdmin):
	fields=('household','household_number','workedin_nonag_operation','worker_name','description_specify_programme', 'type_wage_contract','place_work','number_days','work_hours', 'totalearnings_cash', 'totalearnings_kind', 'income_total')
admin.site.register(Nonaglabour,NonaglabourAdmin)

class EmpfreedomAdmin(admin.ModelAdmin):
	fields=('household' , 'household_number', 'are_familyfree_towork', 'are_familyfree_towork_text', 'does_unpaidlabour_service', 'does_unpaidlabour_service_text', 'member_family_forced_particularemployer', 'member_family_forced_indebted', 'member_family_harassment', 'any_murders_longtermlabours', 'household_obligated_castduties_one', 'household_obligated_castduties_two', 'household_obligated_castduties_three', 'worker_name', 'employer_name', 'employer_caste', 'employer_landowned', 'type_obligation', 'description_task', 'labourdays_worked', 'hours_work', 'work_payment', 'comments',)
admin.site.register(Empfreedom,EmpfreedomAdmin)

class IncomeAdmin(admin.ModelAdmin):
	fields=('household','household_number','item_collected','quantity_consumed','quantity_sold','price','total_earnings','where_sold','marketing_agency','cheating_youface',)
admin.site.register(Income,IncomeAdmin)

class IncomeotherAdmin(admin.ModelAdmin):
	fields=('household','household_number','s_no','worker_name','work_description','work_place','totalnet_earnings','comments',)
admin.site.register(Incomeother,IncomeotherAdmin)

class AnimalsourceAdmin(admin.ModelAdmin):
	fields=('household','household_number','animal_owned','type','nu','age','feed_home_grown','feed_purchased','total_present_value','veternary_charges','maintanence_buildings','insurance','interest_loans_livestock','labour_charges','others','income_production','income_price','total_income','earnings',)
admin.site.register(Animalsource,AnimalsourceAdmin)

