# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'Village'
        db.create_table(u'household_village', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Village'])

        # Adding model 'Mandal'
        db.create_table(u'household_mandal', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Mandal'])

        # Adding model 'District'
        db.create_table(u'household_district', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['District'])

        # Adding model 'Sex'
        db.create_table(u'household_sex', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Sex'])

        # Adding model 'Caste'
        db.create_table(u'household_caste', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Caste'])

        # Adding model 'Year'
        db.create_table(u'household_year', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Year'])

        # Adding model 'Religion'
        db.create_table(u'household_religion', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Religion'])

        # Adding model 'Yesorno'
        db.create_table(u'household_yesorno', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Yesorno'])

        # Adding model 'Numbers'
        db.create_table(u'household_numbers', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.FloatField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Numbers'])

        # Adding model 'Relationship'
        db.create_table(u'household_relationship', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Relationship'])

        # Adding model 'Maritalstatus'
        db.create_table(u'household_maritalstatus', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Maritalstatus'])

        # Adding model 'Literarystatus'
        db.create_table(u'household_literarystatus', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Literarystatus'])

        # Adding model 'Educationlevel'
        db.create_table(u'household_educationlevel', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Educationlevel'])

        # Adding model 'Occupation'
        db.create_table(u'household_occupation', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Occupation'])

        # Adding model 'Base'
        db.create_table(u'household_base', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name_of_household', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('district', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.District'])),
            ('phone', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('age', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Numbers'])),
            ('address', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('father_occupation', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Occupation'])),
            ('tehisil_of_birth', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('sex', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Sex'])),
            ('religion', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Religion'])),
            ('scorst', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Yesorno'])),
            ('father_name', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('village', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Village'])),
            ('year_migration', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Year'])),
            ('mandal', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Mandal'])),
            ('caste', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Caste'])),
            ('comments', self.gf('django.db.models.fields.CharField')(max_length=255, null=True)),
        ))
        db.send_create_signal(u'household', ['Base'])

        # Adding model 'Hhmembers'
        db.create_table(u'household_hhmembers', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name_location_institute', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('occupations_one', self.gf('django.db.models.fields.related.ForeignKey')(related_name=' occupations_one', to=orm['household.Occupation'])),
            ('occupations_two', self.gf('django.db.models.fields.related.ForeignKey')(related_name=' occupations_two', to=orm['household.Occupation'])),
            ('occupations_three', self.gf('django.db.models.fields.related.ForeignKey')(related_name=' occupations_three', to=orm['household.Occupation'])),
            ('age', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Numbers'])),
            ('place_of_work_one', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('place_of_work_two', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('place_of_work_three', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('sex', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Sex'])),
            ('marital_status', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Maritalstatus'])),
            ('education_level', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Educationlevel'])),
            ('relationship_to_head', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Relationship'])),
            ('literary_status', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Literarystatus'])),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'household', ['Hhmembers'])


    def backwards(self, orm):
        # Deleting model 'Village'
        db.delete_table(u'household_village')

        # Deleting model 'Mandal'
        db.delete_table(u'household_mandal')

        # Deleting model 'District'
        db.delete_table(u'household_district')

        # Deleting model 'Sex'
        db.delete_table(u'household_sex')

        # Deleting model 'Caste'
        db.delete_table(u'household_caste')

        # Deleting model 'Year'
        db.delete_table(u'household_year')

        # Deleting model 'Religion'
        db.delete_table(u'household_religion')

        # Deleting model 'Yesorno'
        db.delete_table(u'household_yesorno')

        # Deleting model 'Numbers'
        db.delete_table(u'household_numbers')

        # Deleting model 'Relationship'
        db.delete_table(u'household_relationship')

        # Deleting model 'Maritalstatus'
        db.delete_table(u'household_maritalstatus')

        # Deleting model 'Literarystatus'
        db.delete_table(u'household_literarystatus')

        # Deleting model 'Educationlevel'
        db.delete_table(u'household_educationlevel')

        # Deleting model 'Occupation'
        db.delete_table(u'household_occupation')

        # Deleting model 'Base'
        db.delete_table(u'household_base')

        # Deleting model 'Hhmembers'
        db.delete_table(u'household_hhmembers')


    models = {
        u'household.base': {
            'Meta': {'object_name': 'Base'},
            'address': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'age': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Numbers']"}),
            'caste': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']"}),
            'comments': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True'}),
            'district': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.District']"}),
            'father_name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'father_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'mandal': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Mandal']"}),
            'name_of_household': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'phone': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'religion': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Religion']"}),
            'scorst': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Yesorno']"}),
            'sex': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Sex']"}),
            'tehisil_of_birth': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'village': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Village']"}),
            'year_migration': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Year']"})
        },
        u'household.caste': {
            'Meta': {'object_name': 'Caste'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.district': {
            'Meta': {'object_name': 'District'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.educationlevel': {
            'Meta': {'object_name': 'Educationlevel'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.hhmembers': {
            'Meta': {'object_name': 'Hhmembers'},
            'age': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Numbers']"}),
            'education_level': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Educationlevel']"}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'literary_status': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Literarystatus']"}),
            'marital_status': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Maritalstatus']"}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'name_location_institute': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'occupations_one': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "' occupations_one'", 'to': u"orm['household.Occupation']"}),
            'occupations_three': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "' occupations_three'", 'to': u"orm['household.Occupation']"}),
            'occupations_two': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "' occupations_two'", 'to': u"orm['household.Occupation']"}),
            'place_of_work_one': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'place_of_work_three': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'place_of_work_two': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'relationship_to_head': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Relationship']"}),
            'sex': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Sex']"})
        },
        u'household.literarystatus': {
            'Meta': {'object_name': 'Literarystatus'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.mandal': {
            'Meta': {'object_name': 'Mandal'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.maritalstatus': {
            'Meta': {'object_name': 'Maritalstatus'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.numbers': {
            'Meta': {'object_name': 'Numbers'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.FloatField', [], {'max_length': '255'})
        },
        u'household.occupation': {
            'Meta': {'object_name': 'Occupation'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.relationship': {
            'Meta': {'object_name': 'Relationship'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.religion': {
            'Meta': {'object_name': 'Religion'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.sex': {
            'Meta': {'object_name': 'Sex'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.village': {
            'Meta': {'object_name': 'Village'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.year': {
            'Meta': {'object_name': 'Year'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.yesorno': {
            'Meta': {'object_name': 'Yesorno'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        }
    }

    complete_apps = ['household']