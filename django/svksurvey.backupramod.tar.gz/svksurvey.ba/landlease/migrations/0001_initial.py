# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'Registration'
        db.create_table(u'landlease_registration', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'landlease', ['Registration'])

        # Adding model 'Contracttype'
        db.create_table(u'landlease_contracttype', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'landlease', ['Contracttype'])

        # Adding model 'Kind'
        db.create_table(u'landlease_kind', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'landlease', ['Kind'])

        # Adding model 'Period'
        db.create_table(u'landlease_period', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'landlease', ['Period'])

        # Adding model 'Percent'
        db.create_table(u'landlease_percent', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'landlease', ['Percent'])

        # Adding model 'Landtanent'
        db.create_table(u'landlease_landtanent', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('total', self.gf('django.db.models.fields.FloatField')()),
            ('sharedrent', self.gf('django.db.models.fields.FloatField')()),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('fixedrent', self.gf('django.db.models.fields.FloatField')()),
        ))
        db.send_create_signal(u'landlease', ['Landtanent'])

        # Adding model 'Landleasedin'
        db.create_table(u'landlease_landleasedin', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('tenant_or_not', self.gf('django.db.models.fields.related.ForeignKey')(related_name='tenant_or_not', to=orm['household.Yesorno'])),
            ('input_owner_machinary', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('input_owner_pumpset', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_owner_seed', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('annual_fixedrent_cash', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('landowner_name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('loan_fromowner_interestfree', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('landowner_caste', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Caste'], null=True, blank=True)),
            ('input_owner_pesticide', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('loan_fromowner_withinterest', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('tenurial_registration', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['landlease.Registration'], null=True, blank=True)),
            ('input_owner_fertiliser', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('tenurial_contracttype', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['landlease.Contracttype'], null=True, blank=True)),
            ('extent', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('qty_hay_byowner', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_owner_electricity', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('annual_fixedrent_kind', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['landlease.Kind'], null=True, blank=True)),
            ('input_owner_manure', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('landowner_extent_landholding', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('landtype', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['land.Landtype'], null=True, blank=True)),
            ('tenurial_sincewhen', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('landowner_occupation', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Occupation'], null=True, blank=True)),
        ))
        db.send_create_signal(u'landlease', ['Landleasedin'])

        # Adding model 'Landleaser'
        db.create_table(u'landlease_landleaser', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('total', self.gf('django.db.models.fields.FloatField')()),
            ('sharedrent', self.gf('django.db.models.fields.FloatField')()),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('fixedrent', self.gf('django.db.models.fields.FloatField')()),
            ('comments', self.gf('django.db.models.fields.CharField')(max_length=255, null=True)),
        ))
        db.send_create_signal(u'landlease', ['Landleaser'])

        # Adding model 'Landleasedout'
        db.create_table(u'landlease_landleasedout', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('leaseout_or_not', self.gf('django.db.models.fields.related.ForeignKey')(related_name='leaseout_or_not', to=orm['household.Yesorno'])),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('input_you_pesticide', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_you_pumpset', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('annual_fixedrent_cash', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('landtype', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['land.Landtype'], null=True, blank=True)),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('landtenant_name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('input_you_seed', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_you_machinary', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_you_fertiliser', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_you_manure', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('tenurial_registration', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['landlease.Registration'], null=True, blank=True)),
            ('tenurial_contracttype', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['landlease.Contracttype'], null=True, blank=True)),
            ('extent', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('landtenant_extent_landholding', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('annual_fixedrent_kind', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['landlease.Kind'], null=True, blank=True)),
            ('landtenant_caste', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Caste'], null=True, blank=True)),
            ('loan_fromyou_withinterest', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('loan_fromyou_interestfree', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('qty_hay_bytenant', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('landtenant_occupation', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Occupation'], null=True, blank=True)),
            ('input_you_electricity', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('tenurial_sincewhen', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
        ))
        db.send_create_signal(u'landlease', ['Landleasedout'])

        # Adding model 'Mortgagedin'
        db.create_table(u'landlease_mortgagedin', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('mortgagedin_or_not', self.gf('django.db.models.fields.related.ForeignKey')(related_name='mortgagedin_or_not', to=orm['household.Yesorno'])),
            ('businessman_caste', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Caste'], null=True, blank=True)),
            ('interest', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('year_mortgage', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('businessman_name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('businessman_occupation', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Occupation'], null=True, blank=True)),
            ('mortgage_period', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['landlease.Period'], null=True, blank=True)),
            ('extent', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('landtype', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['land.Landtype'], null=True, blank=True)),
            ('mortgage_amount', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
        ))
        db.send_create_signal(u'landlease', ['Mortgagedin'])

        # Adding model 'Mortgagedout'
        db.create_table(u'landlease_mortgagedout', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('mortgagedout_or_not', self.gf('django.db.models.fields.related.ForeignKey')(related_name='mortgagedout_or_not', to=orm['household.Yesorno'])),
            ('year_mortgage', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('interest', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('mortgagee_caste', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Caste'], null=True, blank=True)),
            ('mortgagee_name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('mortgage_period', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['landlease.Period'], null=True, blank=True)),
            ('extent', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('landtype', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['land.Landtype'], null=True, blank=True)),
            ('mortgagee_occupation', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Occupation'], null=True, blank=True)),
            ('mortgage_amount', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
        ))
        db.send_create_signal(u'landlease', ['Mortgagedout'])

        # Adding model 'Sharerentin'
        db.create_table(u'landlease_sharerentin', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('sharedin_or_not', self.gf('django.db.models.fields.related.ForeignKey')(related_name='sharedin_or_not', to=orm['household.Yesorno'])),
            ('input_owner_machinary_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_owner_machinary_percent', null=True, to=orm['landlease.Percent'])),
            ('input_owner_machinary_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('period', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['landlease.Period'], null=True, blank=True)),
            ('since_when_leased', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('landowner_name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('input_owner_manure_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('input_owner_labor_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('landowner_caste', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Caste'], null=True, blank=True)),
            ('input_owner_elec_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_owner_pump_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_owner_pump_percent', null=True, to=orm['landlease.Percent'])),
            ('input_owner_pest_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_owner_seed_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('owner_share_hay_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='owner_share_percent', null=True, to=orm['landlease.Percent'])),
            ('input_owner_fert_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_owner_fert_percent', null=True, to=orm['landlease.Percent'])),
            ('input_owner_elec_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_owner_elec_percent', null=True, to=orm['landlease.Percent'])),
            ('loan_by_owner_amt', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('owner_share_crop_qty', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_owner_labor_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_owner_labor_percent', null=True, to=orm['landlease.Percent'])),
            ('input_owner_seed_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_owner_seed_percent', null=True, to=orm['landlease.Percent'])),
            ('input_owner_fert_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('owner_share_crop_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='owner_share_crop_percent', null=True, to=orm['landlease.Percent'])),
            ('extent', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_owner_pest_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_owner_pest_percent', null=True, to=orm['landlease.Percent'])),
            ('loan_by_owner_interestfree', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('loan_by_owner_interest', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('loan_by_owner_rateofinterest', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_owner_manure_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_owner_manure_percent', null=True, to=orm['landlease.Percent'])),
            ('landowner_extent_hold', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('landtype', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['land.Landtype'], null=True, blank=True)),
            ('owner_share_hay_qty', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_owner_pump_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('registered_or_not', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['landlease.Registration'], null=True, blank=True)),
            ('landowner_occupation', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Occupation'], null=True, blank=True)),
        ))
        db.send_create_signal(u'landlease', ['Sharerentin'])

        # Adding model 'Sharerentout'
        db.create_table(u'landlease_sharerentout', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('sharedrent_or_not', self.gf('django.db.models.fields.related.ForeignKey')(related_name='sharedrent_or_not', to=orm['household.Yesorno'])),
            ('input_you_elec_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_you_elec_percent', null=True, to=orm['landlease.Percent'])),
            ('cropper_occupation', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='cropper_occupation', null=True, to=orm['household.Occupation'])),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('input_you_seed_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_you_seed_percent', null=True, to=orm['landlease.Percent'])),
            ('period', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='period', null=True, to=orm['landlease.Period'])),
            ('loan_by_you_interestfree', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('loan_by_you_interest', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('loan_by_owner_rateofinterest', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('since_when_leased', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('input_you_pest_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_you_pump_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('tenant_share_hay_qty', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('input_you_elec_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_you_fert_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_you_labor_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_you_fert_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_you_fert_percent', null=True, to=orm['landlease.Percent'])),
            ('cropper_name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('input_you_machinary_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_you_machinary_percent', null=True, to=orm['landlease.Percent'])),
            ('input_you_manure_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('cropper_caste', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='cropper_caste', null=True, to=orm['household.Caste'])),
            ('cropper_extent_hold', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('loan_by_you_amt', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_you_machinary_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('extent', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('tenant_share_crop_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='tenant_share_crop_percent', null=True, to=orm['landlease.Percent'])),
            ('input_you_labor_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_you_labor_percent', null=True, to=orm['landlease.Percent'])),
            ('tenant_share_hay_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='tenant_share_hay_percent', null=True, to=orm['landlease.Percent'])),
            ('input_you_seed_rs', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('input_you_manure_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_you_manure_percent', null=True, to=orm['landlease.Percent'])),
            ('tenant_share_crop_qty', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('landtype', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='landtype', null=True, to=orm['land.Landtype'])),
            ('input_you_pump_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_you_pump_percent', null=True, to=orm['landlease.Percent'])),
            ('registered_or_not', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='registered_or_not', null=True, to=orm['landlease.Registration'])),
            ('input_you_pest_percent', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='input_you_pest_percent', null=True, to=orm['landlease.Percent'])),
        ))
        db.send_create_signal(u'landlease', ['Sharerentout'])

        # Adding model 'Tenantproblems'
        db.create_table(u'landlease_tenantproblems', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('reason_compelled_one', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('inherited_problems', self.gf('django.db.models.fields.related.ForeignKey')(related_name='inherited_problems', to=orm['household.Yesorno'])),
            ('reason_compelled', self.gf('django.db.models.fields.related.ForeignKey')(related_name='reason_compelled', to=orm['household.Yesorno'])),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('why_wageslow_manage', self.gf('django.db.models.fields.related.ForeignKey')(related_name='why_wageslow_manage', to=orm['household.Yesorno'])),
            ('why_lowrent_profitable', self.gf('django.db.models.fields.related.ForeignKey')(related_name='why_lowrent_profitable', to=orm['household.Yesorno'])),
            ('nonereason_tenant', self.gf('django.db.models.fields.related.ForeignKey')(related_name='nonereason_tenant', to=orm['household.Yesorno'])),
            ('why_noskill_urban', self.gf('django.db.models.fields.related.ForeignKey')(related_name='why_noskill_urban', to=orm['household.Yesorno'])),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('why_tenancy_respectable', self.gf('django.db.models.fields.related.ForeignKey')(related_name='why_tenancy_respectable', to=orm['household.Yesorno'])),
            ('comments', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('because_debt_to_leaser', self.gf('django.db.models.fields.related.ForeignKey')(related_name='because_debt_to_leaser', to=orm['household.Yesorno'])),
            ('loan_landowner_prior_tenancy', self.gf('django.db.models.fields.related.ForeignKey')(related_name='loan_landowner_prior_tenancy', to=orm['household.Yesorno'])),
            ('reason_compelled_three', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('lack_anyother_option', self.gf('django.db.models.fields.related.ForeignKey')(related_name='lack_anyother_option', to=orm['household.Yesorno'])),
            ('provide_freeservice_owner', self.gf('django.db.models.fields.related.ForeignKey')(related_name='provide_freeservice_owner', to=orm['household.Yesorno'])),
            ('other_reasons', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('why_for_foodgrains', self.gf('django.db.models.fields.related.ForeignKey')(related_name='why_for_foodgrains', to=orm['household.Yesorno'])),
            ('nature_contract_written', self.gf('django.db.models.fields.related.ForeignKey')(related_name='nature_contract_written', to=orm['household.Yesorno'])),
            ('dueto_lack_opportunites', self.gf('django.db.models.fields.related.ForeignKey')(related_name='dueto_lack_opportunites', to=orm['household.Yesorno'])),
            ('nota_comeout_otherreasons', self.gf('django.db.models.fields.related.ForeignKey')(related_name='nota_comeout_otherreasons', to=orm['household.Yesorno'])),
            ('why_inability_wagework', self.gf('django.db.models.fields.related.ForeignKey')(related_name='why_inability_wagework', to=orm['household.Yesorno'])),
            ('reason_compelled_two', self.gf('django.db.models.fields.CharField')(max_length=255)),
            ('why_ownland_notsufficient', self.gf('django.db.models.fields.related.ForeignKey')(related_name='why_ownland_notsufficient', to=orm['household.Yesorno'])),
            ('why_opportunity_cattle', self.gf('django.db.models.fields.related.ForeignKey')(related_name='why_opportunity_cattle', to=orm['household.Yesorno'])),
            ('debt_inherited', self.gf('django.db.models.fields.related.ForeignKey')(related_name='debt_inherited', to=orm['household.Yesorno'])),
            ('nature_contract_verbal', self.gf('django.db.models.fields.related.ForeignKey')(related_name='nature_contract_verbal', to=orm['household.Yesorno'])),
            ('because_debt_to_leaser_amt', self.gf('django.db.models.fields.FloatField')()),
        ))
        db.send_create_signal(u'landlease', ['Tenantproblems'])

        # Adding model 'Interlinks'
        db.create_table(u'landlease_interlinks', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('comodity_labour', self.gf('django.db.models.fields.related.ForeignKey')(related_name='comodity_labour', to=orm['household.Yesorno'])),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('land_labour', self.gf('django.db.models.fields.related.ForeignKey')(related_name='land_labour', to=orm['household.Yesorno'])),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(related_name='f_household', to=orm['household.Base'])),
            ('inputs_land', self.gf('django.db.models.fields.related.ForeignKey')(related_name='inputs_land', to=orm['household.Yesorno'])),
            ('inputs_loans', self.gf('django.db.models.fields.related.ForeignKey')(related_name='inputs_loans', to=orm['household.Yesorno'])),
            ('inputs_commodity', self.gf('django.db.models.fields.related.ForeignKey')(related_name='inputs_commodity', to=orm['household.Yesorno'])),
            ('loans_commodity', self.gf('django.db.models.fields.related.ForeignKey')(related_name='loans_commodity', to=orm['household.Yesorno'])),
            ('inputs_labour', self.gf('django.db.models.fields.related.ForeignKey')(related_name='inputs_labour', to=orm['household.Yesorno'])),
            ('loans_land', self.gf('django.db.models.fields.related.ForeignKey')(related_name='loans_land', to=orm['household.Yesorno'])),
            ('land_commodity', self.gf('django.db.models.fields.related.ForeignKey')(related_name='land_commodity', to=orm['household.Yesorno'])),
            ('loans_labour', self.gf('django.db.models.fields.related.ForeignKey')(related_name='loans_labour', to=orm['household.Yesorno'])),
        ))
        db.send_create_signal(u'landlease', ['Interlinks'])


    def backwards(self, orm):
        # Deleting model 'Registration'
        db.delete_table(u'landlease_registration')

        # Deleting model 'Contracttype'
        db.delete_table(u'landlease_contracttype')

        # Deleting model 'Kind'
        db.delete_table(u'landlease_kind')

        # Deleting model 'Period'
        db.delete_table(u'landlease_period')

        # Deleting model 'Percent'
        db.delete_table(u'landlease_percent')

        # Deleting model 'Landtanent'
        db.delete_table(u'landlease_landtanent')

        # Deleting model 'Landleasedin'
        db.delete_table(u'landlease_landleasedin')

        # Deleting model 'Landleaser'
        db.delete_table(u'landlease_landleaser')

        # Deleting model 'Landleasedout'
        db.delete_table(u'landlease_landleasedout')

        # Deleting model 'Mortgagedin'
        db.delete_table(u'landlease_mortgagedin')

        # Deleting model 'Mortgagedout'
        db.delete_table(u'landlease_mortgagedout')

        # Deleting model 'Sharerentin'
        db.delete_table(u'landlease_sharerentin')

        # Deleting model 'Sharerentout'
        db.delete_table(u'landlease_sharerentout')

        # Deleting model 'Tenantproblems'
        db.delete_table(u'landlease_tenantproblems')

        # Deleting model 'Interlinks'
        db.delete_table(u'landlease_interlinks')


    models = {
        u'household.base': {
            'Meta': {'object_name': 'Base'},
            'address': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'age': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Numbers']"}),
            'caste': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']"}),
            'district': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.District']"}),
            'father_name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'father_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'mandal': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Mandal']"}),
            'name_of_household': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'phone': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'religion': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Religion']"}),
            'scorst': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Yesorno']"}),
            'sex': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Sex']"}),
            'tehisil_of_birth': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'village': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Village']"}),
            'year_migration': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Year']"})
        },
        u'household.caste': {
            'Meta': {'object_name': 'Caste'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.district': {
            'Meta': {'object_name': 'District'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.mandal': {
            'Meta': {'object_name': 'Mandal'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.numbers': {
            'Meta': {'object_name': 'Numbers'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.FloatField', [], {'max_length': '255'})
        },
        u'household.occupation': {
            'Meta': {'object_name': 'Occupation'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.religion': {
            'Meta': {'object_name': 'Religion'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.sex': {
            'Meta': {'object_name': 'Sex'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.village': {
            'Meta': {'object_name': 'Village'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.year': {
            'Meta': {'object_name': 'Year'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.yesorno': {
            'Meta': {'object_name': 'Yesorno'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'land.landtype': {
            'Meta': {'object_name': 'Landtype'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'landlease.contracttype': {
            'Meta': {'object_name': 'Contracttype'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'landlease.interlinks': {
            'Meta': {'object_name': 'Interlinks'},
            'comodity_labour': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'comodity_labour'", 'to': u"orm['household.Yesorno']"}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'f_household'", 'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'inputs_commodity': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'inputs_commodity'", 'to': u"orm['household.Yesorno']"}),
            'inputs_labour': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'inputs_labour'", 'to': u"orm['household.Yesorno']"}),
            'inputs_land': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'inputs_land'", 'to': u"orm['household.Yesorno']"}),
            'inputs_loans': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'inputs_loans'", 'to': u"orm['household.Yesorno']"}),
            'land_commodity': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'land_commodity'", 'to': u"orm['household.Yesorno']"}),
            'land_labour': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'land_labour'", 'to': u"orm['household.Yesorno']"}),
            'loans_commodity': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'loans_commodity'", 'to': u"orm['household.Yesorno']"}),
            'loans_labour': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'loans_labour'", 'to': u"orm['household.Yesorno']"}),
            'loans_land': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'loans_land'", 'to': u"orm['household.Yesorno']"})
        },
        u'landlease.kind': {
            'Meta': {'object_name': 'Kind'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'landlease.landleasedin': {
            'Meta': {'object_name': 'Landleasedin'},
            'annual_fixedrent_cash': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'annual_fixedrent_kind': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['landlease.Kind']", 'null': 'True', 'blank': 'True'}),
            'extent': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'input_owner_electricity': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_fertiliser': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_machinary': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_manure': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_pesticide': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_pumpset': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_seed': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'landowner_caste': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']", 'null': 'True', 'blank': 'True'}),
            'landowner_extent_landholding': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'landowner_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'landowner_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']", 'null': 'True', 'blank': 'True'}),
            'landtype': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Landtype']", 'null': 'True', 'blank': 'True'}),
            'loan_fromowner_interestfree': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'loan_fromowner_withinterest': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'qty_hay_byowner': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'tenant_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'tenant_or_not'", 'to': u"orm['household.Yesorno']"}),
            'tenurial_contracttype': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['landlease.Contracttype']", 'null': 'True', 'blank': 'True'}),
            'tenurial_registration': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['landlease.Registration']", 'null': 'True', 'blank': 'True'}),
            'tenurial_sincewhen': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'landlease.landleasedout': {
            'Meta': {'object_name': 'Landleasedout'},
            'annual_fixedrent_cash': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'annual_fixedrent_kind': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['landlease.Kind']", 'null': 'True', 'blank': 'True'}),
            'extent': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'input_you_electricity': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_fertiliser': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_machinary': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_manure': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_pesticide': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_pumpset': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_seed': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'landtenant_caste': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']", 'null': 'True', 'blank': 'True'}),
            'landtenant_extent_landholding': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'landtenant_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'landtenant_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']", 'null': 'True', 'blank': 'True'}),
            'landtype': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Landtype']", 'null': 'True', 'blank': 'True'}),
            'leaseout_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'leaseout_or_not'", 'to': u"orm['household.Yesorno']"}),
            'loan_fromyou_interestfree': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'loan_fromyou_withinterest': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'qty_hay_bytenant': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'tenurial_contracttype': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['landlease.Contracttype']", 'null': 'True', 'blank': 'True'}),
            'tenurial_registration': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['landlease.Registration']", 'null': 'True', 'blank': 'True'}),
            'tenurial_sincewhen': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'landlease.landleaser': {
            'Meta': {'object_name': 'Landleaser'},
            'comments': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True'}),
            'fixedrent': ('django.db.models.fields.FloatField', [], {}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'sharedrent': ('django.db.models.fields.FloatField', [], {}),
            'total': ('django.db.models.fields.FloatField', [], {})
        },
        u'landlease.landtanent': {
            'Meta': {'object_name': 'Landtanent'},
            'fixedrent': ('django.db.models.fields.FloatField', [], {}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'sharedrent': ('django.db.models.fields.FloatField', [], {}),
            'total': ('django.db.models.fields.FloatField', [], {})
        },
        u'landlease.mortgagedin': {
            'Meta': {'object_name': 'Mortgagedin'},
            'businessman_caste': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']", 'null': 'True', 'blank': 'True'}),
            'businessman_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'businessman_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']", 'null': 'True', 'blank': 'True'}),
            'extent': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'interest': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'landtype': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Landtype']", 'null': 'True', 'blank': 'True'}),
            'mortgage_amount': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'mortgage_period': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['landlease.Period']", 'null': 'True', 'blank': 'True'}),
            'mortgagedin_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'mortgagedin_or_not'", 'to': u"orm['household.Yesorno']"}),
            'year_mortgage': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'landlease.mortgagedout': {
            'Meta': {'object_name': 'Mortgagedout'},
            'extent': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'interest': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'landtype': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Landtype']", 'null': 'True', 'blank': 'True'}),
            'mortgage_amount': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'mortgage_period': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['landlease.Period']", 'null': 'True', 'blank': 'True'}),
            'mortgagedout_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'mortgagedout_or_not'", 'to': u"orm['household.Yesorno']"}),
            'mortgagee_caste': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']", 'null': 'True', 'blank': 'True'}),
            'mortgagee_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'mortgagee_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']", 'null': 'True', 'blank': 'True'}),
            'year_mortgage': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'landlease.percent': {
            'Meta': {'object_name': 'Percent'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'landlease.period': {
            'Meta': {'object_name': 'Period'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'landlease.registration': {
            'Meta': {'object_name': 'Registration'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'landlease.sharerentin': {
            'Meta': {'object_name': 'Sharerentin'},
            'extent': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'input_owner_elec_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_owner_elec_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_owner_elec_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_fert_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_owner_fert_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_owner_fert_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_labor_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_owner_labor_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_owner_labor_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_machinary_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_owner_machinary_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_owner_machinary_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_manure_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_owner_manure_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_owner_manure_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_pest_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_owner_pest_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_owner_pest_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_pump_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_owner_pump_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_owner_pump_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_owner_seed_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_owner_seed_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_owner_seed_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'landowner_caste': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']", 'null': 'True', 'blank': 'True'}),
            'landowner_extent_hold': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'landowner_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'landowner_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']", 'null': 'True', 'blank': 'True'}),
            'landtype': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Landtype']", 'null': 'True', 'blank': 'True'}),
            'loan_by_owner_amt': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'loan_by_owner_interest': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'loan_by_owner_interestfree': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'loan_by_owner_rateofinterest': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'owner_share_crop_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'owner_share_crop_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'owner_share_crop_qty': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'owner_share_hay_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'owner_share_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'owner_share_hay_qty': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'period': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['landlease.Period']", 'null': 'True', 'blank': 'True'}),
            'registered_or_not': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['landlease.Registration']", 'null': 'True', 'blank': 'True'}),
            'sharedin_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'sharedin_or_not'", 'to': u"orm['household.Yesorno']"}),
            'since_when_leased': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'landlease.sharerentout': {
            'Meta': {'object_name': 'Sharerentout'},
            'cropper_caste': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'cropper_caste'", 'null': 'True', 'to': u"orm['household.Caste']"}),
            'cropper_extent_hold': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'cropper_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'cropper_occupation': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'cropper_occupation'", 'null': 'True', 'to': u"orm['household.Occupation']"}),
            'extent': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'input_you_elec_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_you_elec_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_you_elec_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_fert_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_you_fert_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_you_fert_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_labor_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_you_labor_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_you_labor_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_machinary_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_you_machinary_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_you_machinary_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_manure_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_you_manure_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_you_manure_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_pest_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_you_pest_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_you_pest_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_pump_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_you_pump_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_you_pump_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'input_you_seed_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'input_you_seed_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'input_you_seed_rs': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'landtype': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'landtype'", 'null': 'True', 'to': u"orm['land.Landtype']"}),
            'loan_by_owner_rateofinterest': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'loan_by_you_amt': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'loan_by_you_interest': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'loan_by_you_interestfree': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'period': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'period'", 'null': 'True', 'to': u"orm['landlease.Period']"}),
            'registered_or_not': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'registered_or_not'", 'null': 'True', 'to': u"orm['landlease.Registration']"}),
            'sharedrent_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'sharedrent_or_not'", 'to': u"orm['household.Yesorno']"}),
            'since_when_leased': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'tenant_share_crop_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'tenant_share_crop_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'tenant_share_crop_qty': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'tenant_share_hay_percent': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'tenant_share_hay_percent'", 'null': 'True', 'to': u"orm['landlease.Percent']"}),
            'tenant_share_hay_qty': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'})
        },
        u'landlease.tenantproblems': {
            'Meta': {'object_name': 'Tenantproblems'},
            'because_debt_to_leaser': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'because_debt_to_leaser'", 'to': u"orm['household.Yesorno']"}),
            'because_debt_to_leaser_amt': ('django.db.models.fields.FloatField', [], {}),
            'comments': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'debt_inherited': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'debt_inherited'", 'to': u"orm['household.Yesorno']"}),
            'dueto_lack_opportunites': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'dueto_lack_opportunites'", 'to': u"orm['household.Yesorno']"}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'inherited_problems': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'inherited_problems'", 'to': u"orm['household.Yesorno']"}),
            'lack_anyother_option': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'lack_anyother_option'", 'to': u"orm['household.Yesorno']"}),
            'loan_landowner_prior_tenancy': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'loan_landowner_prior_tenancy'", 'to': u"orm['household.Yesorno']"}),
            'nature_contract_verbal': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'nature_contract_verbal'", 'to': u"orm['household.Yesorno']"}),
            'nature_contract_written': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'nature_contract_written'", 'to': u"orm['household.Yesorno']"}),
            'nonereason_tenant': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'nonereason_tenant'", 'to': u"orm['household.Yesorno']"}),
            'nota_comeout_otherreasons': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'nota_comeout_otherreasons'", 'to': u"orm['household.Yesorno']"}),
            'other_reasons': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'provide_freeservice_owner': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'provide_freeservice_owner'", 'to': u"orm['household.Yesorno']"}),
            'reason_compelled': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'reason_compelled'", 'to': u"orm['household.Yesorno']"}),
            'reason_compelled_one': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'reason_compelled_three': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'reason_compelled_two': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'why_for_foodgrains': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'why_for_foodgrains'", 'to': u"orm['household.Yesorno']"}),
            'why_inability_wagework': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'why_inability_wagework'", 'to': u"orm['household.Yesorno']"}),
            'why_lowrent_profitable': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'why_lowrent_profitable'", 'to': u"orm['household.Yesorno']"}),
            'why_noskill_urban': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'why_noskill_urban'", 'to': u"orm['household.Yesorno']"}),
            'why_opportunity_cattle': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'why_opportunity_cattle'", 'to': u"orm['household.Yesorno']"}),
            'why_ownland_notsufficient': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'why_ownland_notsufficient'", 'to': u"orm['household.Yesorno']"}),
            'why_tenancy_respectable': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'why_tenancy_respectable'", 'to': u"orm['household.Yesorno']"}),
            'why_wageslow_manage': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'why_wageslow_manage'", 'to': u"orm['household.Yesorno']"})
        }
    }

    complete_apps = ['landlease']