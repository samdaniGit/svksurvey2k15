from django.db import models

# Create your models here.
class Village(models.Model):
	name = models.CharField(verbose_name='గ్రామము', max_length=255)
 

