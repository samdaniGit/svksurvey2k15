# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Adding model 'Landtype'
        db.create_table(u'land_landtype', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
        ))
        db.send_create_signal(u'land', ['Landtype'])

        # Adding model 'Irrigationsource'
        db.create_table(u'land_irrigationsource', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
        ))
        db.send_create_signal(u'land', ['Irrigationsource'])

        # Adding model 'Irrigationflow'
        db.create_table(u'land_irrigationflow', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
        ))
        db.send_create_signal(u'land', ['Irrigationflow'])

        # Adding model 'Irrigationownship'
        db.create_table(u'land_irrigationownship', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
        ))
        db.send_create_signal(u'land', ['Irrigationownship'])

        # Adding model 'Aquireland'
        db.create_table(u'land_aquireland', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
        ))
        db.send_create_signal(u'land', ['Aquireland'])

        # Adding model 'Reasonforsale'
        db.create_table(u'land_reasonforsale', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
        ))
        db.send_create_signal(u'land', ['Reasonforsale'])

        # Adding model 'Currentownership'
        db.create_table(u'land_currentownership', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('landowned_or_not', self.gf('django.db.models.fields.related.ForeignKey')(related_name='landowned_or_not', to=orm['household.Yesorno'])),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('irrigationownship', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationownship', null=True, to=orm['land.Irrigationownship'])),
            ('irrigationownship_one', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationownship_one', null=True, to=orm['land.Irrigationownship'])),
            ('irrigationownship_two', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationownship_two', null=True, to=orm['land.Irrigationownship'])),
            ('irrigationownship_three', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationownship_three', null=True, to=orm['land.Irrigationownship'])),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('how_aquireland', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['land.Aquireland'], null=True, blank=True)),
            ('extent_of_owned', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('value', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('patta_for_land', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='patta_for_land', null=True, to=orm['household.Yesorno'])),
            ('landtype', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['land.Landtype'], null=True, blank=True)),
            ('irrigationflow', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationflow', null=True, to=orm['land.Irrigationflow'])),
            ('irrigationsource', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationsource', null=True, to=orm['land.Irrigationsource'])),
            ('irrigationflow_one', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationflow_one', null=True, to=orm['land.Irrigationflow'])),
            ('irrigationsource_one', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationsource_one', null=True, to=orm['land.Irrigationsource'])),
            ('irrigationflow_two', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationflow_two', null=True, to=orm['land.Irrigationflow'])),
            ('irrigationsource_two', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationsource_two', null=True, to=orm['land.Irrigationsource'])),
            ('irrigationflow_three', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationflow_three', null=True, to=orm['land.Irrigationflow'])),
            ('irrigationsource_three', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='irrigationsource_three', null=True, to=orm['land.Irrigationsource'])),
        ))
        db.send_create_signal(u'land', ['Currentownership'])

        # Adding model 'Landsold'
        db.create_table(u'land_landsold', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('land_sold_or_not', self.gf('django.db.models.fields.related.ForeignKey')(related_name='land_sold_or_not', to=orm['household.Yesorno'])),
            ('buyer_name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('price_land', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('type_of_land', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['land.Landtype'], null=True, blank=True)),
            ('year_of_sale', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Year'], null=True, blank=True)),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('buyer_occupation', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Occupation'], null=True, blank=True)),
            ('buyer_place_residence', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('buyer_catse', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Caste'], null=True, blank=True)),
            ('extent', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('reason_for_sale', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['land.Reasonforsale'], null=True, blank=True)),
        ))
        db.send_create_signal(u'land', ['Landsold'])

        # Adding model 'Landbought'
        db.create_table(u'land_landbought', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('land_bought_or_not', self.gf('django.db.models.fields.related.ForeignKey')(related_name='land_bought_or_not', to=orm['household.Yesorno'])),
            ('seller_catse', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Caste'], null=True, blank=True)),
            ('seller_occupation', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Occupation'], null=True, blank=True)),
            ('household_number', self.gf('django.db.models.fields.FloatField')()),
            ('seller_name', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('price_land', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('type_of_land', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['land.Landtype'], null=True, blank=True)),
            ('household', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Base'])),
            ('extent', self.gf('django.db.models.fields.FloatField')(null=True, blank=True)),
            ('seller_place_residence', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('year_of_purchase', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['household.Year'], null=True, blank=True)),
            ('income_source', self.gf('django.db.models.fields.CharField')(max_length=255, null=True, blank=True)),
            ('comments', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal(u'land', ['Landbought'])


    def backwards(self, orm):
        # Deleting model 'Landtype'
        db.delete_table(u'land_landtype')

        # Deleting model 'Irrigationsource'
        db.delete_table(u'land_irrigationsource')

        # Deleting model 'Irrigationflow'
        db.delete_table(u'land_irrigationflow')

        # Deleting model 'Irrigationownship'
        db.delete_table(u'land_irrigationownship')

        # Deleting model 'Aquireland'
        db.delete_table(u'land_aquireland')

        # Deleting model 'Reasonforsale'
        db.delete_table(u'land_reasonforsale')

        # Deleting model 'Currentownership'
        db.delete_table(u'land_currentownership')

        # Deleting model 'Landsold'
        db.delete_table(u'land_landsold')

        # Deleting model 'Landbought'
        db.delete_table(u'land_landbought')


    models = {
        u'household.base': {
            'Meta': {'object_name': 'Base'},
            'address': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'age': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Numbers']"}),
            'caste': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']"}),
            'district': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.District']"}),
            'father_name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'father_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'mandal': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Mandal']"}),
            'name_of_household': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'phone': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'religion': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Religion']"}),
            'scorst': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Yesorno']"}),
            'sex': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Sex']"}),
            'tehisil_of_birth': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'village': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Village']"}),
            'year_migration': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Year']"})
        },
        u'household.caste': {
            'Meta': {'object_name': 'Caste'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.district': {
            'Meta': {'object_name': 'District'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.mandal': {
            'Meta': {'object_name': 'Mandal'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.numbers': {
            'Meta': {'object_name': 'Numbers'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.FloatField', [], {'max_length': '255'})
        },
        u'household.occupation': {
            'Meta': {'object_name': 'Occupation'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.religion': {
            'Meta': {'object_name': 'Religion'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.sex': {
            'Meta': {'object_name': 'Sex'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.village': {
            'Meta': {'object_name': 'Village'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.year': {
            'Meta': {'object_name': 'Year'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.yesorno': {
            'Meta': {'object_name': 'Yesorno'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'land.aquireland': {
            'Meta': {'object_name': 'Aquireland'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'land.currentownership': {
            'Meta': {'object_name': 'Currentownership'},
            'extent_of_owned': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            'how_aquireland': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Aquireland']", 'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'irrigationflow': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationflow'", 'null': 'True', 'to': u"orm['land.Irrigationflow']"}),
            'irrigationflow_one': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationflow_one'", 'null': 'True', 'to': u"orm['land.Irrigationflow']"}),
            'irrigationflow_three': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationflow_three'", 'null': 'True', 'to': u"orm['land.Irrigationflow']"}),
            'irrigationflow_two': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationflow_two'", 'null': 'True', 'to': u"orm['land.Irrigationflow']"}),
            'irrigationownship': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationownship'", 'null': 'True', 'to': u"orm['land.Irrigationownship']"}),
            'irrigationownship_one': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationownship_one'", 'null': 'True', 'to': u"orm['land.Irrigationownship']"}),
            'irrigationownship_three': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationownship_three'", 'null': 'True', 'to': u"orm['land.Irrigationownship']"}),
            'irrigationownship_two': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationownship_two'", 'null': 'True', 'to': u"orm['land.Irrigationownship']"}),
            'irrigationsource': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationsource'", 'null': 'True', 'to': u"orm['land.Irrigationsource']"}),
            'irrigationsource_one': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationsource_one'", 'null': 'True', 'to': u"orm['land.Irrigationsource']"}),
            'irrigationsource_three': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationsource_three'", 'null': 'True', 'to': u"orm['land.Irrigationsource']"}),
            'irrigationsource_two': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationsource_two'", 'null': 'True', 'to': u"orm['land.Irrigationsource']"}),
            'landowned_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'landowned_or_not'", 'to': u"orm['household.Yesorno']"}),
            'landtype': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Landtype']", 'null': 'True', 'blank': 'True'}),
            'patta_for_land': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'patta_for_land'", 'null': 'True', 'to': u"orm['household.Yesorno']"}),
            'value': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'})
        },
        u'land.irrigationflow': {
            'Meta': {'object_name': 'Irrigationflow'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'land.irrigationownship': {
            'Meta': {'object_name': 'Irrigationownship'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'land.irrigationsource': {
            'Meta': {'object_name': 'Irrigationsource'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'land.landbought': {
            'Meta': {'object_name': 'Landbought'},
            'comments': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'extent': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'income_source': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'land_bought_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'land_bought_or_not'", 'to': u"orm['household.Yesorno']"}),
            'price_land': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'seller_catse': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']", 'null': 'True', 'blank': 'True'}),
            'seller_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'seller_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']", 'null': 'True', 'blank': 'True'}),
            'seller_place_residence': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'type_of_land': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Landtype']", 'null': 'True', 'blank': 'True'}),
            'year_of_purchase': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Year']", 'null': 'True', 'blank': 'True'})
        },
        u'land.landsold': {
            'Meta': {'object_name': 'Landsold'},
            'buyer_catse': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']", 'null': 'True', 'blank': 'True'}),
            'buyer_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'buyer_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']", 'null': 'True', 'blank': 'True'}),
            'buyer_place_residence': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'extent': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'land_sold_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'land_sold_or_not'", 'to': u"orm['household.Yesorno']"}),
            'price_land': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'reason_for_sale': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Reasonforsale']", 'null': 'True', 'blank': 'True'}),
            'type_of_land': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Landtype']", 'null': 'True', 'blank': 'True'}),
            'year_of_sale': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Year']", 'null': 'True', 'blank': 'True'})
        },
        u'land.landtype': {
            'Meta': {'object_name': 'Landtype'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'land.reasonforsale': {
            'Meta': {'object_name': 'Reasonforsale'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        }
    }

    complete_apps = ['land']