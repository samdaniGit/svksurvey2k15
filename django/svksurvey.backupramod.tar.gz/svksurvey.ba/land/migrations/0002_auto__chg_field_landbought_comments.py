# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):

        # Changing field 'Landbought.comments'
        db.alter_column(u'land_landbought', 'comments', self.gf('django.db.models.fields.CharField')(max_length=255, null=True))

    def backwards(self, orm):

        # User chose to not deal with backwards NULL issues for 'Landbought.comments'
        raise RuntimeError("Cannot reverse this migration. 'Landbought.comments' and its values cannot be restored.")
        
        # The following code is provided here to aid in writing a correct migration
        # Changing field 'Landbought.comments'
        db.alter_column(u'land_landbought', 'comments', self.gf('django.db.models.fields.CharField')(max_length=255))

    models = {
        u'household.base': {
            'Meta': {'object_name': 'Base'},
            'address': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'age': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Numbers']"}),
            'caste': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']"}),
            'district': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.District']"}),
            'father_name': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'father_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'mandal': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Mandal']"}),
            'name_of_household': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'phone': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'religion': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Religion']"}),
            'scorst': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Yesorno']"}),
            'sex': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Sex']"}),
            'tehisil_of_birth': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'village': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Village']"}),
            'year_migration': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Year']"})
        },
        u'household.caste': {
            'Meta': {'object_name': 'Caste'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.district': {
            'Meta': {'object_name': 'District'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.mandal': {
            'Meta': {'object_name': 'Mandal'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.numbers': {
            'Meta': {'object_name': 'Numbers'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.FloatField', [], {'max_length': '255'})
        },
        u'household.occupation': {
            'Meta': {'object_name': 'Occupation'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.religion': {
            'Meta': {'object_name': 'Religion'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.sex': {
            'Meta': {'object_name': 'Sex'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.village': {
            'Meta': {'object_name': 'Village'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.year': {
            'Meta': {'object_name': 'Year'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'household.yesorno': {
            'Meta': {'object_name': 'Yesorno'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        },
        u'land.aquireland': {
            'Meta': {'object_name': 'Aquireland'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'land.currentownership': {
            'Meta': {'object_name': 'Currentownership'},
            'extent_of_owned': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            'how_aquireland': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Aquireland']", 'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'irrigationflow': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationflow'", 'null': 'True', 'to': u"orm['land.Irrigationflow']"}),
            'irrigationflow_one': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationflow_one'", 'null': 'True', 'to': u"orm['land.Irrigationflow']"}),
            'irrigationflow_three': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationflow_three'", 'null': 'True', 'to': u"orm['land.Irrigationflow']"}),
            'irrigationflow_two': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationflow_two'", 'null': 'True', 'to': u"orm['land.Irrigationflow']"}),
            'irrigationownship': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationownship'", 'null': 'True', 'to': u"orm['land.Irrigationownship']"}),
            'irrigationownship_one': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationownship_one'", 'null': 'True', 'to': u"orm['land.Irrigationownship']"}),
            'irrigationownship_three': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationownship_three'", 'null': 'True', 'to': u"orm['land.Irrigationownship']"}),
            'irrigationownship_two': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationownship_two'", 'null': 'True', 'to': u"orm['land.Irrigationownship']"}),
            'irrigationsource': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationsource'", 'null': 'True', 'to': u"orm['land.Irrigationsource']"}),
            'irrigationsource_one': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationsource_one'", 'null': 'True', 'to': u"orm['land.Irrigationsource']"}),
            'irrigationsource_three': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationsource_three'", 'null': 'True', 'to': u"orm['land.Irrigationsource']"}),
            'irrigationsource_two': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'irrigationsource_two'", 'null': 'True', 'to': u"orm['land.Irrigationsource']"}),
            'landowned_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'landowned_or_not'", 'to': u"orm['household.Yesorno']"}),
            'landtype': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Landtype']", 'null': 'True', 'blank': 'True'}),
            'patta_for_land': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'patta_for_land'", 'null': 'True', 'to': u"orm['household.Yesorno']"}),
            'value': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'})
        },
        u'land.irrigationflow': {
            'Meta': {'object_name': 'Irrigationflow'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'land.irrigationownship': {
            'Meta': {'object_name': 'Irrigationownship'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'land.irrigationsource': {
            'Meta': {'object_name': 'Irrigationsource'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'land.landbought': {
            'Meta': {'object_name': 'Landbought'},
            'comments': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'extent': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'income_source': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'land_bought_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'land_bought_or_not'", 'to': u"orm['household.Yesorno']"}),
            'price_land': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'seller_catse': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']", 'null': 'True', 'blank': 'True'}),
            'seller_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'seller_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']", 'null': 'True', 'blank': 'True'}),
            'seller_place_residence': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'type_of_land': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Landtype']", 'null': 'True', 'blank': 'True'}),
            'year_of_purchase': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Year']", 'null': 'True', 'blank': 'True'})
        },
        u'land.landsold': {
            'Meta': {'object_name': 'Landsold'},
            'buyer_catse': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Caste']", 'null': 'True', 'blank': 'True'}),
            'buyer_name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'buyer_occupation': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Occupation']", 'null': 'True', 'blank': 'True'}),
            'buyer_place_residence': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'}),
            'extent': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'household': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Base']"}),
            'household_number': ('django.db.models.fields.FloatField', [], {}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'land_sold_or_not': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'land_sold_or_not'", 'to': u"orm['household.Yesorno']"}),
            'price_land': ('django.db.models.fields.FloatField', [], {'null': 'True', 'blank': 'True'}),
            'reason_for_sale': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Reasonforsale']", 'null': 'True', 'blank': 'True'}),
            'type_of_land': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['land.Landtype']", 'null': 'True', 'blank': 'True'}),
            'year_of_sale': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['household.Year']", 'null': 'True', 'blank': 'True'})
        },
        u'land.landtype': {
            'Meta': {'object_name': 'Landtype'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        },
        u'land.reasonforsale': {
            'Meta': {'object_name': 'Reasonforsale'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '255', 'null': 'True', 'blank': 'True'})
        }
    }

    complete_apps = ['land']