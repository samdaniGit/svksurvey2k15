from django.db import models
from household.models import *
from land.models import *
from landlease.models import *

# Create your models here.
class Crop(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Otheractivities(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Tenurialstatus(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Marketingplace(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Fertilisertype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Transportmode(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Itemcode(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Tubewelltype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Businessactivities(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Tasksperformed(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Time(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Productionsales(models.Model):
	sale_wasthe_price_fixedbefore = models.ForeignKey(Yesorno, related_name = "sale_wasthe_price_fixedbefore")
	household = models.ForeignKey(Base)
	crop = models.ForeignKey(Crop)
	market_expense = models.IntegerField()
	source_irrigation = models.ForeignKey(Irrigationsource, related_name = "source_irrigation")
	production_straw = models.IntegerField()
	sale_by_products_price = models.IntegerField()
	tenurial_status = models.ForeignKey(Tenurialstatus, related_name = "tenurial_status")
	sale_marketing_agency = models.IntegerField()
	household_number = models.IntegerField()
	sale_quantity = models.IntegerField()
	month_harvesting = models.DateTimeField()
	income_oncrop = models.IntegerField()
	sale_transport_cost = models.IntegerField()
	household_consumption_straw = models.IntegerField()
	sale_price = models.IntegerField()
	net_income = models.IntegerField()
	sale_transport_mode = models.ForeignKey(Transportmode, related_name = "sale_transport_mode")
	sale_where_marketed = models.ForeignKey(Marketingplace, related_name = "sale_where_marketed")
	month_sowing = models.DateTimeField()
	production_grain = models.IntegerField()
	household_consumpion_grain = models.IntegerField()
	extent = models.IntegerField()
	s_no = models.ForeignKey(Numbers)
	sale_other_marketing_costs = models.IntegerField()
	sale_month_disposal = models.DateTimeField()
	income_on_products = models.IntegerField()
	total_income = models.IntegerField()
	sale_by_products_amt = models.IntegerField()
	def __str__(self):
                return self.crop

class Inputs(models.Model):
	seeds_home_value = models.IntegerField()
	irrigation_charges_source = models.ForeignKey(Irrigationsource, related_name = "irrigation_charges_source")
	fertiliser_transport_mode = models.ForeignKey(Transportmode, related_name = "fertiliser_transport_mode")
	seeds_purchased_cost = models.IntegerField()
	household = models.ForeignKey(Base)
	crop = models.ForeignKey(Crop, related_name = "crop")
	manure_purchased_qty = models.IntegerField()
	fertiliser_transport_costincurred = models.IntegerField()
	seeds_purchased_price = models.IntegerField()
	irrigation_charges_price = models.IntegerField()
	manure_home_value = models.IntegerField()
	household_number = models.IntegerField()
	manure_purchased_cost = models.IntegerField()
	fertiliser_type = models.ForeignKey(Fertilisertype, related_name = "fertiliser_type")
	manure_purchased_price = models.IntegerField()
	fertiliser_qty = models.IntegerField()
	advice_regarding_cultivation = models.CharField(max_length=255)
	irrigation_charges_totalcost = models.IntegerField()
	manure_transport_mode = models.ForeignKey(Transportmode, related_name = "manure_transport_mode")
	seeds_home_qty = models.IntegerField()
	manure_transport_costincurred = models.IntegerField()
	fertiliser_cost = models.IntegerField()
	seeds_home_cost = models.IntegerField()
	s_no = models.ForeignKey(Numbers)
	manure_home_qty = models.IntegerField()
	manure_home_cost = models.IntegerField()
	plant_protection_value = models.IntegerField()
	seeds_purchased_qty = models.IntegerField()
	fertiliser_price = models.IntegerField()
	def __str__(self):
                return self.crop

class Specifiedproduction(models.Model):
	ownership_yearpurchase = models.ForeignKey(Year, related_name = "ownership_yearpurchase")
	household_number = models.IntegerField()
	maintenance_charges_lastyear = models.IntegerField()
	household = models.ForeignKey(Base)
	comments = models.CharField(max_length=255)
	ownership_subsidy_received = models.IntegerField()
	ownership_number = models.ForeignKey(Numbers, related_name = "ownership_number")
	itemcode = models.ForeignKey(Itemcode, related_name = "itemcode")
	ownership_presentvalue = models.IntegerField()
	rental_earnings_units = models.IntegerField()
	total_earnings = models.IntegerField()
	rental_earnings = models.IntegerField()
	ownership_pricepaid_perunit = models.IntegerField()
	def __str__(self):
                return str(self.household_number)

class Tubewells(models.Model):
	operated_other_sale_totalrevenue = models.IntegerField()
	operated_other_crop = models.ForeignKey(Crop, related_name = "operated_other_crop")
	household_number = models.IntegerField()
	depth_present = models.IntegerField()
	household = models.ForeignKey(Base)
	depth_installed = models.IntegerField()
	comments = models.CharField(max_length=255)
	operated_other_sale_area = models.IntegerField()
	year_installed = models.ForeignKey(Year, related_name = "year_installed")
	maintanence_last_year = models.IntegerField()
	total_earnings = models.IntegerField()
	cost_installation = models.IntegerField()
	type = models.ForeignKey(Tubewelltype, related_name = "type")
	s_no = models.ForeignKey(Numbers, related_name = "s_no")
	def __str__(self):
                return (self.household_number)

class Othercosts(models.Model):
	amount_spent = models.IntegerField()
	household = models.ForeignKey(Base)
	household_number = models.IntegerField()
	item_code = models.ForeignKey(Itemcode, related_name = "item_code")
	comments = models.CharField(max_length=255)
	def __str__(self):
                return str(self.amount_spent)

class Managerpayments(models.Model):
	payments_inkind = models.CharField(max_length=255)
	household_number = models.IntegerField()
	employ_longterm_lastyear = models.ForeignKey(Yesorno, related_name = "employ_longterm_lastyear")
	household = models.ForeignKey(Base)
	payments_incash = models.IntegerField()
	comments = models.CharField(max_length=255)
	number_months = models.IntegerField()
	name_worker = models.CharField(max_length=255)
	payments_total = models.IntegerField()
	since_when = models.DateTimeField()
	employ_manager_lastyear = models.ForeignKey(Yesorno, related_name = "employ_manager_lastyear")
	caste = models.ForeignKey(Caste, related_name = "caste")
	def __str__(self):
                return str(payments_incash)

class Longtermworker(models.Model):
	illness_get_help = models.ForeignKey(Yesorno, related_name = "illness_get_help")
	household = models.ForeignKey(Base)
	tasks_performed_two = models.ForeignKey(Tasksperformed, related_name = "tasks_performed_two")
	number_months = models.IntegerField()
	name_worker = models.CharField(max_length=255)
	total = models.IntegerField()
	earning_cash = models.IntegerField()
	household_number = models.IntegerField()
	occupation_manager = models.ForeignKey(Occupation, related_name = "occupation_manager")
	subjectd_harassments_describe = models.CharField(max_length=255)
	land_leasedin_mortin = models.IntegerField()
	illness_get_help_text = models.CharField(max_length=255)
	tasks_performed_three = models.ForeignKey(Tasksperformed, related_name = "tasks_performed_three")
	caste_worker = models.ForeignKey(Caste, related_name = "caste_worker")
	working_from = models.ForeignKey(Time, related_name = "working_from")
	caste_manager = models.ForeignKey(Caste, related_name = "caste_manager")
	earning_kind = models.IntegerField()
	get_number_days_off = models.ForeignKey(Numbers, related_name = "get_number_days_off")
	subjected_harassments = models.ForeignKey(Yesorno, related_name = "subjected_harassments")
	other_business_activities = models.ForeignKey(Otheractivities, related_name = "other_business_activities")
	land_leasedout_mortout = models.IntegerField()
	working_to = models.ForeignKey(Time, related_name = "working_to")
	tasks_performed_one = models.ForeignKey(Tasksperformed, related_name = "tasks_performed_one")
	land_owned = models.IntegerField()
	name_manager = models.CharField(max_length=255)
	def __str__(self):
                return name_worker

