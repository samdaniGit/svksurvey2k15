from django.db import models
from household.models import *
from land.models import *
from landlease.models import *
from cropping.models import *
from labourwages.models import *
# Create your models here.
class Ownedorrented(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Cardcolor(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Cardtype(models.Model):
        name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Rooftype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Walltype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Floortype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Latrinetype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Electricitytype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Sourcecooking(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Naturereimbusment(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Interesttype(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Borrowingsource(models.Model):
	name = models.CharField(max_length=255)
	def __str__(self):
                return self.name

class Houbase(models.Model):
	household = models.ForeignKey(Base)
	govtscheme_nature_reimbusment = models.ForeignKey(Naturereimbusment, related_name = "govtscheme_nature_reimbusment")
	value_of_house = models.IntegerField()
	year_recent_repair = models.ForeignKey(Year, related_name = "year_recent_repair")
	type_roof = models.ForeignKey(Rooftype, related_name = "type_roof")
	type_wall = models.ForeignKey(Walltype, related_name = "type_wall")
	household_number = models.IntegerField()
	source_energy_cooking = models.ForeignKey(Sourcecooking, related_name = "source_energy_cooking")
	electricity = models.ForeignKey(Electricitytype, related_name = "electricity")
	comments = models.CharField(max_length=255)
	isthere_kitchen = models.ForeignKey(Yesorno, related_name = "isthere_kitchen")
	availbility_safe_drinking_text = models.CharField(max_length=255)
	noof_additional_rooms = models.ForeignKey(Numbers, related_name = "noof_additional_rooms")
	owned_or_rented = models.ForeignKey(Ownedorrented, related_name = "owned_or_rented")
	govtscheme_cash = models.IntegerField()
	amount_spending_water = models.IntegerField()
	enough_water_text = models.CharField(max_length=255)
	s_no = models.ForeignKey(Numbers)
	year_construction = models.ForeignKey(Year, related_name = "year_construction")
	latrine = models.ForeignKey(Latrinetype, related_name = "latrine")
	does_house_have_watertap = models.ForeignKey(Yesorno, related_name = "does_house_have_watertap")
	type_of_floor = models.ForeignKey(Floortype, related_name = "type_of_floor")
	govtscheme_yes_or_no = models.ForeignKey(Yesorno, related_name = "govtscheme_yes_or_no")
	isthere_veranda = models.ForeignKey(Yesorno, related_name = "isthere-veranda")
	govtscheme_year = models.ForeignKey(Year, related_name = "govtscheme_year")
	def __str__(self):
                return str(self.value_of_house)

class Indebtedness(models.Model):
	collateral = models.IntegerField()
	amont_repaid = models.IntegerField()
	household_number = models.IntegerField()
	amount_outstanding_principal = models.IntegerField()
	amount_outstanding_interest = models.IntegerField()
	household = models.ForeignKey(Base)
	source_borrowing = models.ForeignKey(Borrowingsource, related_name = "source_borrowing")
	purpose_borrowing = models.CharField(max_length=255)
	month_year = models.DateTimeField()
	thing_indebtedness = models.CharField(max_length=255)
	amount_outstanding_total = models.IntegerField()
	loan_no = models.ForeignKey(Numbers, related_name = "loan_no")
	type_interest = models.ForeignKey(Interesttype, related_name = "type_interest")
	rate_interest = models.IntegerField()
	principal = models.IntegerField()
	def __str__(self):
                return str(self.collateral)

class Selfhelpgroups(models.Model):
	period_member = models.ForeignKey(Period, related_name = "period_member")
	household_number = models.IntegerField()
	bank_group_linked = models.CharField(max_length=255)
	household = models.ForeignKey(Base)
	name_group = models.CharField(max_length=255)
	savings_permonth = models.IntegerField()
	name_group_leader = models.CharField(max_length=255)
	savings_total = models.IntegerField()
	name_member = models.CharField(max_length=255)
	savings_perweek = models.IntegerField()
	number_members_group = models.ForeignKey(Numbers, related_name = "number_members_group")
	def __str__(self):
                return self.name_group

class Assets(models.Model):
	anyother_land_value = models.IntegerField()
	transport_car_value = models.IntegerField()
	ponds_tanks_area = models.IntegerField()
	transport_lorry_no = models.ForeignKey(Numbers, related_name = "transport_lorry_no")
	household = models.ForeignKey(Base)
	electronics_mobile_no = models.ForeignKey(Numbers, related_name = "electronics_mobile_no")
	transport_bullockcart_no = models.ForeignKey(Numbers, related_name = "transport_bullockcart_no")
	transport_lorry_value = models.IntegerField()
	electronics_mixy_no = models.ForeignKey(Numbers, related_name = "electronics_mixy_no")
	electronics_refrigerator_value = models.IntegerField()
	buildings_cattleshed_value = models.IntegerField()
	electronics_refrigerator_no = models.ForeignKey(Numbers, related_name = "electronics_refrigerator_no")
	woman_land_patta = models.ForeignKey(Yesorno, related_name = "woman_land_patta")
	durables_tailoringmachine_value = models.IntegerField()
	durables_kitchenset_no = models.ForeignKey(Numbers, related_name = "durables_kitchenset_no")
	anyother_land_area = models.IntegerField()
	investments_gold_value = models.IntegerField()
	household_number = models.IntegerField()
	durables_wwatch_no = models.ForeignKey(Numbers, related_name = "durables_wwatch_no")
	electronics_mobile_value = models.IntegerField()
	electronics_grinder_no = models.ForeignKey(Numbers, related_name = "electronics_grinder_no")
	investments_chitfunds_value = models.IntegerField()
	transport_bullockcart_value = models.IntegerField()
	agricultural_land_area = models.IntegerField()
	electronics_dish_value = models.IntegerField()
	electronics_fan_no = models.ForeignKey(Numbers, related_name = "electronics_fan_no")
	agricultural_land_value = models.IntegerField()
	electronics_fan_value = models.IntegerField()
	homestead_land_area = models.IntegerField()
	transport_moped_value = models.IntegerField()
	durables_kitchenset_value = models.IntegerField()
	durables_wwatch_value = models.IntegerField()
	durables_tailoringmachine_no = models.ForeignKey(Numbers, related_name = "durables_tailoringmachine_no")
	investments_gold_no = models.ForeignKey(Numbers, related_name = "investments_gold_no")
	transport_tractor_value = models.IntegerField()
	electronics_ac_value = models.IntegerField()
	electronics_dish_no = models.ForeignKey(Numbers, related_name = "electronics_dish_no")
	woman_land_patta_text = models.CharField(max_length=255)
	buildings_shop_no = models.ForeignKey(Numbers, related_name = "buildings_shop_no")
	electronics_ac_no = models.ForeignKey(Numbers, related_name = "electronics_ac_no")
	durables_handpump_no = models.ForeignKey(Numbers, related_name = "durables_handpump_no")
	durables_biogas_no = models.ForeignKey(Numbers, related_name = "durables_biogas_no")
	transport_other_value = models.IntegerField()
	buildings_anyother_value = models.IntegerField()
	transport_scooter_no = models.ForeignKey(Numbers, related_name = "transport_scooter_no")
	ponds_tanks_value = models.IntegerField()
	electronics_mixy_value = models.IntegerField()
	buildings_anyother_no = models.ForeignKey(Numbers, related_name = "buildings_anyother_no")
	investments_bonds_value = models.IntegerField()
	electronics_washingmachine_value = models.IntegerField()
	transport_scooter_value = models.IntegerField()
	electronics_grinder_value = models.IntegerField()
	transport_bicycle_value = models.IntegerField()
	electronics_colortv_no = models.ForeignKey(Numbers, related_name = "electronics_colortv_no")
	investments_chitfunds_no = models.ForeignKey(Numbers, related_name = "investments_chitfunds_no")
	electronics_colortv_value = models.IntegerField()
	electronics_cable_no = models.ForeignKey(Numbers, related_name = "electronics_cable_no")
	transport_moped_no = models.ForeignKey(Numbers, related_name = "transport_moped_no")
	buildings_shop_value = models.IntegerField()
	investments_bonds_no = models.ForeignKey(Numbers, related_name = "investments_bonds_no")
	transport_bus_value = models.IntegerField()
	durables_biogas_value = models.IntegerField()
	electronics_washingmachine_no = models.ForeignKey(Numbers, related_name = "electronics_washingmachine_no")
	transport_tractor_no = models.ForeignKey(Numbers, related_name = "transport_tractor_no")
	transport_car_no = models.ForeignKey(Numbers, related_name = "transport_car_no")
	buildings_cattleshed_no = models.ForeignKey(Numbers, related_name = "buildings_cattleshed_no")
	transport_other_no = models.ForeignKey(Numbers, related_name = "transport_other_no")
	transport_bicycle_no = models.ForeignKey(Numbers, related_name = "transport_bicycle_no")
	transport_bus_no = models.ForeignKey(Numbers, related_name = "transport_bus_no")
	electronics_cable_value = models.IntegerField()
	electronics_telephone_value = models.IntegerField()
	durables_gasstove_value = models.IntegerField()
	electronics_telephone_no = models.ForeignKey(Numbers, related_name = "electronics_telephone_no")
	homestead_land_value = models.IntegerField()
	buildings_house_value = models.IntegerField()
	durables_handpump_value = models.IntegerField()
	buildings_house_no = models.ForeignKey(Numbers, related_name = "buildings_house_no")
	durables_gasstove_no = models.ForeignKey(Numbers, related_name = "durables_gasstove_no")
	def __str__(self):
                return str(self.household_number)

class Govtdistrib(models.Model):
	ration_available_intime = models.ForeignKey(Yesorno, related_name = "ration_available_intime")
	ration_weights_perfect = models.ForeignKey(Yesorno, related_name = "ration_weights_perfect")
	household_number = models.IntegerField()
	number_registered = models.ForeignKey(Numbers, related_name = "number_registered")
	ration_buy_onetime = models.ForeignKey(Yesorno, related_name = "ration_buy_onetime")
	household = models.ForeignKey(Base)
	reasons_for_nocard = models.CharField(max_length=255)
	card_color = models.ForeignKey(Cardcolor, related_name = "card_color")
	ration_reasonable_price = models.ForeignKey(Yesorno, related_name = "ration_reasonable_price")
	comments = models.CharField(max_length=255)
	card_type = models.ForeignKey(Cardtype, related_name = "card_type")
	ration_buy_multipletimes_accept = models.ForeignKey(Yesorno, related_name = "ration_buy_multipletimes_accept")
	number_registered_adults = models.ForeignKey(Numbers, related_name = "number_registered_adults")
	rationcard_exist = models.ForeignKey(Yesorno, related_name = "rationcard_exist")
	number_registered_kids = models.ForeignKey(Numbers, related_name = "number_registered_kids")
	ration_available_sufficient = models.ForeignKey(Yesorno, related_name = "ration_available_sufficient")
	def __str__(self):
                return str(self.household_number)
