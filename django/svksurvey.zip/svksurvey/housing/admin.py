from django.contrib import admin
from housing.models import *

# Register your models here.

class OwnedorrentedAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Ownedorrented,OwnedorrentedAdmin)

class CardcolorAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Cardcolor,CardcolorAdmin)

class CardtypeAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Cardtype,CardtypeAdmin)

class RooftypeAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Rooftype,RooftypeAdmin)

class WalltypeAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Walltype,WalltypeAdmin)

class FloortypeAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Floortype,FloortypeAdmin)

class LatrinetypeAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Latrinetype,LatrinetypeAdmin)

class ElectricitytypeAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Electricitytype,ElectricitytypeAdmin)

class SourcecookingAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Sourcecooking,SourcecookingAdmin)

class NaturereimbusmentAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Naturereimbusment,NaturereimbusmentAdmin)

class InteresttypeAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Interesttype,InteresttypeAdmin)

class BorrowingsourceAdmin(admin.ModelAdmin):
	fields=('name',)
admin.site.register(Borrowingsource,BorrowingsourceAdmin)

class HoubaseAdmin(admin.ModelAdmin):
	fields=('household','household_number','s_no','owned_or_rented','year_construction','year_recent_repair',)
admin.site.register(Houbase,HoubaseAdmin)

class IndebtednessAdmin(admin.ModelAdmin):
	fields=('household','household_number','loan_no','month_year','principal','collateral','thing_indebtedness','type_interest','rate_interest','amount_outstanding_principal','amount_outstanding_interest','amount_outstanding_total','amont_repaid','source_borrowing','purpose_borrowing',)
admin.site.register(Indebtedness,IndebtednessAdmin)

class SelfhelpgroupsAdmin(admin.ModelAdmin):
	fields=('household','household_number','name_member','name_group','name_group_leader','bank_group_linked','period_member','number_members_group','savings_perweek','savings_permonth','savings_total',)
admin.site.register(Selfhelpgroups,SelfhelpgroupsAdmin)

class AssetsAdmin(admin.ModelAdmin):
	fields=('household','household_number','agricultural_land_area','agricultural_land_value','homestead_land_area','homestead_land_value',)
admin.site.register(Assets,AssetsAdmin)

class GovtdistribAdmin(admin.ModelAdmin):
	fields=('household','household_number','rationcard_exist','card_type','card_color','number_registered','number_registered_adults','number_registered_kids','reasons_for_nocard','comments','ration_available_intime','ration_available_sufficient','ration_reasonable_price','ration_weights_perfect','ration_buy_onetime','ration_buy_multipletimes_accept',)
admin.site.register(Govtdistrib,GovtdistribAdmin)

