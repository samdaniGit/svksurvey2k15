from django.db import models
#-*- coding: utf-8 -*- 
# Create your models here.
class Village(models.Model):
	name = models.CharField(verbose_name='గ్రామము', max_length=255)
	def __str__(self):
		return self.name 
class Mandal(models.Model):
	name = models.CharField(verbose_name='మండలం', max_length=255)
	def __str__(self):
                return self.name

class District(models.Model):
	name = models.CharField(verbose_name='జిల్లా', max_length=255)
	def __str__(self):
                return self.name

class Sex(models.Model):
	name = models.CharField( max_length=255)
	def __str__(self):
                return self.name

class Caste(models.Model):
	name = models.CharField(verbose_name='కులం' , max_length=255)
	def __str__(self):
                return self.name

class Year(models.Model):
	name = models.CharField(verbose_name='సంవత్సరము' , max_length=255)
	def __str__(self):
                return self.name

class Religion(models.Model):
	name = models.CharField(verbose_name='మతం' , max_length=255)
	def __str__(self):
                return self.name

class Yesorno(models.Model):
	name = models.CharField(verbose_name='అవునులేదా కాదు' , max_length=255)
	def __str__(self):
                return self.name

class Numbers(models.Model):
	name = models.IntegerField(verbose_name='సంఖ్యలు' , max_length=255)
	def __str__(self):
                return str(self.name)
        
class Relationship(models.Model):
	name = models.CharField(verbose_name='సంబంధాలు' , max_length=255)
	def __str__(self):
                return self.name

class Maritalstatus(models.Model):
	name = models.CharField(verbose_name='వైవాహిక స్థితి' , max_length=255)
	def __str__(self):
                return self.name

class Literarystatus(models.Model):
	name = models.CharField(verbose_name='సాహిత్య స్థాయిి' , max_length=255)
	def __str__(self):
                return self.name

class Educationlevel(models.Model):
	name = models.CharField(verbose_name='విద్య స్థాయి' , max_length=255)
	def __str__(self):
                return self.name

class Occupation(models.Model):
	name = models.CharField(verbose_name='వృత్తి' , max_length=255)
	def __str__(self):
                return self.name


class Base(models.Model):
	name_of_household = models.CharField(max_length=255)
	household_number = models.IntegerField( )
	district = models.ForeignKey(District, verbose_name = u'జిల్లా ')
	phone = models.CharField(max_length=255)
	age = models.ForeignKey(Numbers)
	address = models.CharField(max_length=255)
	father_occupation = models.ForeignKey(Occupation)
	tehisil_of_birth = models.CharField(max_length=255)
	sex = models.ForeignKey(Sex)
	religion = models.ForeignKey(Religion)
	scorst = models.ForeignKey(Yesorno)
	father_name = models.CharField(max_length=255)
	village = models.ForeignKey(Village)
	year_migration = models.ForeignKey(Year)
	mandal = models.ForeignKey(Mandal)
	caste = models.ForeignKey(Caste)
	def __str__(self):
                return self.name_of_household

class Hhmembers(models.Model):
	name_location_institute = models.CharField(max_length=255)
	household_number = models.IntegerField()
	occupations = models.ForeignKey(Occupation)
	age = models.ForeignKey(Numbers)
	place_of_work = models.CharField(max_length=255)
	sex = models.ForeignKey(Sex)
	marital_status = models.ForeignKey(Maritalstatus)
	education_level = models.ForeignKey(Educationlevel)
	relationship_to_head = models.ForeignKey(Relationship)
	literary_status = models.ForeignKey(Literarystatus)
	household = models.ForeignKey(Base)
	name = models.CharField(max_length=255)
	def __str__(self):
                return name

